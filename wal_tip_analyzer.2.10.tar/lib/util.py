#! /usr/bin/python
"""
 History:
  08Nov2020 ym186001  1.00 Initial release

 Description:
  This is library for frequently-used operation

"""
version='1.00'

import re, sys

def get_pyver():
  # Return current running Python version
  return '.'.join(map(str, sys.version_info[0:3]))

# Before python 2.7, format() has no feature to add comma 
def commify(num):
  if isinstance(num, int):
    num = str(num)

  ptn_commify = re.compile(r'([+-]?\d+)(\d{3})')
  while True:
    num, num_of_sub = ptn_commify.subn(r'\1,\2', num)
    if num_of_sub == 0:
      break
  return num

def get_os_ver(etc_suse_release=None):
  ver = [None] * 2
  if not etc_suse_release:
     etc_suse_release = open('/etc/SuSE-release' , 'r')
  
  ptn_ver   = re.compile(r'VERSION = (\d+)')
  ptn_patch = re.compile(r'PATCHLEVEL = (\d+)')
  for line in etc_suse_release:
     match = ptn_ver.search(line)
     if match:
        ver[0] = match.group(1)
     match = ptn_patch.search(line)
     if match:
        ver[1] = match.group(1)

  if ver[0] is None or ver[1] is None:
     return False
  return ver

