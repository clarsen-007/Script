#! /usr/bin/python
"""
 History:
  17Jan2020 ym186001  X.XX (Being developed)

 Description:
  This module provides API so python script operates
  ferret utility 

"""
version='1.00'

import sys, os, time
import re
from cnsutil import cnstool

class ferret(cnstool):

  tid_ptn = re.compile(r'(\d+ \d+ \d+)\s+\((0x[0-9A-F]{4} 0x[0-9A-F]{4} 0x[0-9A-F]{4})\)')

  def __init__(self):
    super(ferret, self).__init__('ferret')
    self.end_msg    = 'Ferret Exited'
    # ferret returns 'Reading' right after submitting command
    self.prompt_str = 'Ferret  ==>' 

  def scope_tblname(self, tblname):
    tid = None
    for line in self.run_cmd('tableid "%s"' % tblname.strip()):
      match = tid_ptn.search(line)
      if match:
        tid = match.group(1)
        break

    if not tid:
      return False
 
    for line in self.run_cmd('scope table %s' % tid):
      if 'The SCOPE has been set' in line:
        return True
    
    return False
