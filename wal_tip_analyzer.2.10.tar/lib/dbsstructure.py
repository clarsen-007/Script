#! /usr/bin/python
"""
 History:
  19Nov2020 ym186001  1.00 Initial release

 Description:
  Provide API so Python script can handle DBS internal data structure.

"""
version='1.00'

import re

class MsgHdr(object):
   def __init__(self):
      self.cls        = None
      self.kind       = None
      self.sessionno  = None
      self.requestno  = None
      self.transactionno  = [None] * 3

   ptn_class     = re.compile(r'class = (\d+|0x[0-9a-f]+),')
   ptn_kind      = re.compile(r'kind = (\d+|0x[0-9a-f]+),')
   ptn_sessionno = re.compile(r'sessionno = {(\d+|0x[0-9a-f]+), (\d+|0x[0-9a-f]+)}')
   ptn_requestno = re.compile(r'requestno = {(\d+|0x[0-9a-f]+), (\d+|0x[0-9a-f]+)}')
   ptn_peno      = re.compile(r'procid = (\d+|0x[0-9a-f]+)')   
   ptn_txnno2    = re.compile(r'uniq = {(\d+|0x[0-9a-f]+), (\d+|0x[0-9a-f]+)}')   
   def parse_msghdr(self, msghdr_txt):
      for line in msghdr_txt:
         match = self.ptn_sessionno.search(line)
         if match:
            self.sessionno = int( '%04x' % int(match.group(1)) + '%04x' % int(match.group(2)), 16)

         match = self.ptn_peno.search(line)
         if match:
            self.transactionno[0] = match.group(1)

         match = self.ptn_txnno2.search(line)
         if match:
            self.transactionno[1] = match.group(1)
            self.transactionno[2] = match.group(2)

         match = self.ptn_requestno.search(line)
         if match:
            self.requestno = int( '%04x' % int(match.group(1)) + '%04x' % int(match.group(2)), 16)
  
