#! /usr/bin/python
"""
 History:
  25Feb2020 ym186001  1.00 Initial release

 Description:
  Provide API for network related operation

"""
version='1.00'

import socket

def is_valid_hostname(hostname):
   if not hostname:
      return False

   try:
      socket.gethostbyname(hostname)
      return True
   except socket.error:
      return False


def main():
   print(is_valid_hostname('localhost'))

if __name__ == '__main__':
   main()
