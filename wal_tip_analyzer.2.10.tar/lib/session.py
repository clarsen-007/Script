#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:
  This module provides API so python script can operate 
  session related operation(e.g. qrysessn)

"""
version='1.00'

import sys, os
import re
from cnsutil import cnstool  # super class

class qrysessn(cnstool):

   def __init__(self):
      super(qrysessn, self).__init__('qrysessn')
      self.end_msg    = 'QrySession has terminated'
      self.quit_cmd   = ''

   # Session state/username may have white space
   ptn_ses_dtl   = re.compile(r'(?:State details |State Detail): (.+)\s*$')
   ptn_host2usr  = re.compile(r'(\d+)\s+(\d+)  (\d+)  (\S.*)\s*$')
   ptn_timestamp = re.compile(r'Utility : (\d\d/\d\d/\d\d  \d\d:\d\d:\d\d)')

   def get_session_report(self, sesno=''):
      """
      Return : SessionReport object
      Input   
        sesno: session# to be checked. It'll get all sessions if not specified.
        You can specify multiple session#s as list.

      """
      if sesno == '':
         sesnos = ['*']
      elif isinstance(sesno, str):
         sesnos = sesno.split(' ')
      elif isinstance(sesno, int):
         sesnos = [sesno]
      elif (type(sesno) == list
           or type(sesno) == tuple):
         sesnos = sesno
      else:
         return False

      sessns  = {}
      ses_rpt = SessionReport()
      for sesno in sesnos:
         sesno = str(sesno)
         cmd   = ['*', sesno, '', 'y']
         if sesno == '*':
            cmd= ['*', sesno, 'y']

         sessn = None
         for line in self.run_cmd( cmd ):
            match = self.ptn_timestamp.search(line)
            if match:
               ses_rpt.timestamp = match.group(1)

            match = self.ptn_host2usr.search(line)
            if match:
               sessn = Session(match.group(2))
               sessn.host  = match.group(1)
               sessn.pe    = match.group(3)
               sessn.user  = match.group(4)

            match = self.ptn_ses_dtl.search(line)
            if match:
               sessn.state = match.group(1)
               sessns[sessn.sesno] = sessn

      ses_rpt.ses_dict = sessns
      return ses_rpt # SessionReport object

class SessionReport(object):

   def __init__(self):
      self.timestamp = None # Collect timestamp in qrysessn
      self.ses_dict  = {}   # Key: SesNo(str)  Value: Session object

   def get_session(self, sesno):
      """
      Input  : session number(str or int)
      Return : session object
      """
      return self.ses_dict.get(str(sesno))

   def get_sesno(self):
      return list(self.ses_dict.keys())


class Session(object):

   def __init__(self, sesno=''):
      self.sesno = sesno
      self.host  = None
      self.pe    = None
      self.user  = None
      self.state = None

   def get_sesno(self):
      return self.sesno

   def get_host(self):
      return self.host

   def get_pe(self):
      return self.pe

   def get_user(self):
      return self.user

   def get_state(self):
      return self.state

