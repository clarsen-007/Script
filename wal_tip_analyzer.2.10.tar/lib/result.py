#! /usr/bin/python
"""
 History:
  17Jan2020 ym186001  X.XX (Being developed)

 Description:
  Provides API so python script can handle
  dump related operation(e.g. gdb) 

"""
version='1.00'

import sys, os
import re
from getpass import getpass
from extutil import ExternalUtil  # super class

class tdgdb(ExternalUtil):

   def __init__(self):
      super(tdgdb, self).__init__('tdgdb')
      self.path     = '/usr/pde/bin/gdb'
      self.server   = 'dbs2'          # Dump server
      self.user     = 'crashdumps'    
      self.pw       = None
      self.dumpdb   = 'crashdumps'
      self.dumptbl  = None
      self.rawdump  = None

      self.subp = self.startproc(self.path)

   def set_dump_server(self, server='dbs2'):
      self.server = server

   def set_crash(self, dumpdb='crashdumps'):
      self.dumpdb = dumpdb
      return self.run_cmd('set crash %s:%s' % (self.server, dumpdb))

   def attach_dump(self, dump):
      return self.run_cmd('at dump %s' % dump)

   def run_cmd(self, cmd, discard_output=False):
      p = self.subp

      print('run cmd:' + cmd)
      p.stdin.write( cmd + '\n' )
      p.stdin.write( 'shell echo END_OF_COMMAND\n' )
      p.stdin.flush()

      for line in iter(p.stdout.readline, ''):
         p.stdout.flush()

         #out_line.append(line)
         if self.m_to_stdout:
            sys.stdout.write(line)
   
         self.log(line.rstrip())

         if 'END_OF_COMMAND' in line:
            raise StopIteration

         if discard_output:
            continue
         yield line

   def quit(self):
      self.run_cmd('quit')

   def __del__(self):
      if self.auto_quit:
         self.quit()
      if self.subp:
         self.subp.terminate()


