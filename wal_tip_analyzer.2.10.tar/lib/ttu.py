#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:
  This module provides API so you can easily operate TTU 
  such as bteq via python script.


"""
version='1.00'

import sys, os, time, datetime
import re

from row     import RowBuilder
from extutil import ExternalUtil  # super class

class TTU(ExternalUtil):
   def __init__(self, util):
      super(TTU,self).__init__(util)
      self.charset     = 'utf8'
      self.tdpid       = None
      self.user        = None
      self.pw          = None
      self.is_loggedon       = False    # if logged on now

   def set_charset(self, charset):
      self.charset   = charset

   def set_logon(self, user, pw, tdpid='dbc'):
      self.tdpid       = tdpid
      self.user        = user
      self.pw          = pw


# Pattern to find non-success case
# 'Warning' entails ':'
ptn_nosucc = re.compile(r'\*\*\* (Failure|Error|Warning:) (\d{4})')

class bteq(TTU):

   ptn_num_row_col = re.compile(r'Query completed. (One|\d+) rows? found. (One|\d+) columns? returned')

   def __init__(self):
      super(bteq ,self).__init__('bteq')
      self.path        = '/usr/bin/bteq'

      self.width       = 300    # bteq default is 75
      self.txnmode     = None
      self.separator   = '|'    # field separator
      self.quit_cmd    = '.quit'
      self.sql_ret     = None   # Return code for the last sql
      self.titledashes = True
      self.out_line    = []     # bteq output 

   def set_width(self, width):
      self.width     = width

   # txnmode is BTET or ANSI
   def set_txnmode(self, txnmode):
      if (txnmode.upper() == 'BTET' 
          or txnmode.upper() == 'ANSI'):
         self.txnmode   = txnmode.upper()

   def set_separator(self, separator='|'):
      self.separator = separator

   
   def _do_logon(self):
      """
        Invoke bteq and do initial setup
      """
      if (not self.tdpid
          or not self.user
          or not self.pw):
         raise Exception('logon info is not set!\n')

      p = self.startproc(self.path)
      self.subp = p

      # transaction mode must be specified before logon
      if self.txnmode:
         p.stdin.write('.set session transaction %s\n' % self.txnmode)      

      p.stdin.write('.logon %s/%s,%s\n' % (self.tdpid, self.user, self.pw))      

      if self.charset:
         p.stdin.write('.set session charset "%s"\n' % self.charset)      


      # Read output till first prompt
      done = False
      fail = ''
      for line in iter(p.stdout.readline, ''):
         if self.m_to_stdout:
            sys.stdout.write(line)

         self.log(line.rstrip())

         if '*** ' in line:
            done = True

  
         if '*** Error:' in line:
            fail = line
            
         if done and '+---------+' in line:
            break

         p.stdout.flush()

      if fail:
         raise Exception('Failed to logon!!\n')

      self.is_loggedon = True

      if self.width:
         self.run_sql('.width %d' % self.width)

      if self.separator:
         self.run_sql(".separator '%s'" % self.separator)

      return
      
   def run_sclr_sql(self, sql):
      """
      run scalar query(i.e. result is 1 row & 1 value)
      if the sql returns multiple rows/columns, this returns 1st row/column only.
      """

      if not self.titledashes:
         self.run_sql('.titledashes on')

      rslt = self.run_sql(sql, for_scalar=True)
 
      if not self.titledashes:
         self.run_sql('.titledashes off')
      return rslt

   def run_sql(self, sql, for_scalar=False):
      """
      run sql and read output till the next prompt.
      """
      if not self.is_loggedon:
         self._do_logon()

      p = self.subp

      p.stdin.write(sql.rstrip() + ';\n')
      p.stdin.flush()

      # command which starts with dot '.' is bteq command, not sql
      dot_cmd = False
      if sql.lstrip()[0] == '.':
         dot_cmd = True

      self.out_line        = []
      error           = None
      run_sql         = False
      done            = False
      found_titledash = False
      scalar          = None
      ret             = '0'

      for line in iter(p.stdout.readline, ''):
         if self.m_to_stdout:
            sys.stdout.write(line)

         self.log(line.rstrip())

         self.out_line.append(line)

         if '*** ' in line:
            #run_sql = True
            done = True
            
         match = ptn_nosucc.search(line)
         if match:
            ret = match.group(2)

         if dot_cmd and re.search(r'^\s*\.', line):
            done = True

         if '*** Error:' in line:
            error = line
            
         if 'You are now logged off' in line:
            self.is_loggedon = False

         if found_titledash and not scalar:
            scalar = line.split(' ')[0]

         if line[0] == '-':
            found_titledash = True

         if '+---------+' in line:
            if done:
               break

         p.stdout.flush()
      # End of for (bteq output readline())

      self.sql_ret = ret

      if for_scalar:
         return scalar

      return self.out_line
   # End of run_sql()

   def get_row(self):
      """
      Return result of the last SQL as gerator of Row object.
      """
      if (not self.out_line
         or self.sql_ret != '0'):
         return

      rb = RowBuilder()
  
      rb.set_starttag('^\s*-')
      rb.set_endtag(r'^s*$')
      rb.set_strip_chr(r' ')
      rb.set_separator(self.separator)
      rb.set_input(self.out_line)

      rg = rb.get_generator()

      return rg

   def get_sql_ret(self):
      return self.sql_ret

   def quit(self):
      self.run_sql(self.quit_cmd)

   def __del__(self):
      if self.subp:
         if self.is_loggedon and self.auto_quit:
            self.quit()
         self.subp.terminate()
      return
# End of bteq class
