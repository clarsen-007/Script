#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release
  01Feb2021 ym186001  1.10 Added run_cmd() and run_cmd_shell()

 Description:
  This module provides API so you can easily operate external utility 
  via python script.

  This is intended for utilities/tools like:
  - you need to interactively write command and read its output.
  e.g. ssh

"""
version='1.10'

import sys, os, time, datetime
import subprocess
import re


class ExternalUtil(object):
   """
   Work as API so python script operates any external utility 

   """

   @staticmethod
   def startproc(cmd, buf_size=1):
      if isinstance(cmd, str):
         cmds = cmd.split()
      else:
         cmds = cmd 

      p = subprocess.Popen(cmds,
               stdin=subprocess.PIPE,
               stdout=subprocess.PIPE,
               #stderr=subprocess.PIPE
               stderr=subprocess.STDOUT
               ,universal_newlines=True  # open in text mode
               ,bufsize=buf_size         # Default 1(line buffer)
      )
      return p
   
   @staticmethod
   def run_cmd(cmd, buf_size=1, shell=False):
      # For Python 2.6 or earlier, subprocess does not have check_output() yet
      if isinstance(cmd, str):
         cmds = cmd.split()
      else:
         cmds = cmd 

      p = subprocess.Popen(cmds,
               stdin=subprocess.PIPE,
               stdout=subprocess.PIPE,
               stderr=subprocess.STDOUT
               ,universal_newlines=True  # open in text mode
               ,bufsize=buf_size         # Default 1(line buffer)
               ,shell=shell
      )

      for line in iter(p.stdout.readline, ''):
         yield line 
      return
    
   @staticmethod
   def run_cmd_shell(cmd, buf_size=1):
       return ExternalUtil.run_cmd(cmd, buf_size, True)

   def __init__(self, util=None):
      """
      Parameters

      """
      self.util        = util  # utility name
      self.path        = util  # utility path
      self.m_to_stdout = True  
      self.logfnc      = None  # logging function
      self.dbglogfnc   = None  # logging function for debug
      self.subp        = None
      self.hdr         = None
      self.debug       = False
      self.auto_quit   = True  # automatically quit the utility in destructor 
      self.m_return_output = True 

   def set_auto_quit(self, auto_quit=True):
      self.auto_quit   = auto_quit

   # set utility command path
   def set_path(self, path):
      self.path        = path

   def return_output(self, return_output=True):
      """
      When False, output from external util is not returned to caller.
      False is used to save memory when the output is huge.
      """
      self.m_return_output = return_output

   def to_stdout(self, to_stdout=True):
      """
      Switch if printing utility output to stdout or not 

      Parameters
       to_stdout : boolean    

      """
      self.m_to_stdout = to_stdout

   # Set header/tag for cnstool output
   def set_hdr(self, hdr=None):
      """
      Set header/tag for each line of cns output.
      header will be enclosed with []

      Parameters
       hdr : str    

      """
      if hdr == None and self.util:
         self.hdr = self.util # default: utility name
      elif hdr == False:     
         self.hdr = None
      elif type(hdr) == str: 
         self.hdr = hdr

   # Set logging function
   def set_logfnc(self, logfnc, to_stdout=False): 
      self.logfnc      = logfnc
      # By default, not write to stdout when logfnc is set
      self.m_to_stdout = to_stdout

   # Call logging function if set
   def log(self, msg_body): 
      if not callable(self.logfnc):
         return False
      msg = ''
      if self.hdr:
         msg += '%s ' % self.hdr
      msg += msg_body

      # We can't expect what Exception is thrown from outer log function.
      # But we shoud not be halted for logging error.
      try:
         self.logfnc(msg)
      except Exception as e:
         print('Got exception during logging "%s". Ignoring' % msg.rstrip())
         print('Exception message: "%s"' % e)

   def set_debug(self, debug=True):
      self.debug = debug

   # Set logging function
   def set_dbglogfnc(self, dbglogfnc, to_stdout=False): 
      self.dbglogfnc      = dbglogfnc
      # By default, not write to stdout when logfnc is set
      self.m_to_stdout = to_stdout

   def dbglog(self, msg_body):
      if not self.debug:
         return

      for line in msg_body.split('\n'):
         print('DEBUG: ' + line.rstrip())
      return

      msg = ''
      if self.hdr:
         msg += '%s ' % self.hdr
      msg += msg_body
     
      # We can't expect what Exception is thrown from outer log function.
      # But we shoud not be halted for logging error.
      try:
         self.dbglogfnc(msg)
      except Exception as e:
         print('Got exception during logging "%s". Ignoring.' % (msg.rstrip()))
         print('Exception message: "%s"' % e)

   def __del__(self):
      if not self.auto_quit:
         return
      if self.subp.poll() is not None:
         self.subp.terminate()

## End of ExternalUtil class
  

