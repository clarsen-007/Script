#! /usr/bin/python
"""
 History:
  07Nov2020 ym186001  1.00 Initial Release
  19Nov2020 ym186001  1.10 Added set_frame(). Added 'Continuing.' as break condition
                           in _read_gdbout( as break condition
                           in _read_gdbout()
  08Dec2020 ym186001  1.11 info_raw() skips empty line and error output
                           
 Description:
  Provides API so python script can handle
  dump related operation(e.g. gdb csppeek) 

"""
version='1.00'

import sys, os
import re
from signal    import SIGINT

from getpass   import getpass
from extutil   import ExternalUtil  # super class
from vproc     import Vproc, Vconfig
from tpanode   import TPANode
from dbsthread import DBSThread, DBSThreads, backtrace

class tdgdb(ExternalUtil):

   def __init__(self, dumpname=None):
      super(tdgdb, self).__init__('tdgdb')
      self.path      = '/usr/pde/bin/gdb'
      self.server    = 'dbs2'          # Dump server
      self.user      = 'crashdumps'    
      self.pw        = 'crashdumps'
      self.dumpdb    = 'crashdumps'
      self.dumpname  = dumpname
      self.type      = 'dump'   # dump or raw
      self.out_gnrtr = []
      self.scr       = 0
      self.prpr      = True
      self.cur_context  = None

      self.subp = self.startproc([self.path, '-q'])


   class ConnectionClosed(Exception):
      pass


   def set_dump_server(self, server):
      self.server = server

   def set_dumpdb(self, dumpdb):
      self.dumpdb = dumpdb

   def set_user(self, user):
      self.user = user

   def set_pw(self, pw):
      self.pw = pw

   def attach_dump(self, dumpname=None):
      if dumpname:
         self.dumpname = dumpname

      if self.type == 'dump':
         self.run_cmd('user %s %s' % (self.user, self.pw), False)
         self.run_cmd('set crash %s:%s' % (self.server, self.dumpdb))

      self.run_cmd('set scr %d' % self.scr)
      if self.prpr: self.run_cmd('set pr pr') 

      outline = []
      ptn_install_pde = re.compile(r'(Please install PDE Version \S+) on')
      ptn_os_ver_err  = re.compile(r'(The running version of the OS = .* is incompatable with the dump version  = .*) ')
      for line in self.run_cmd('at %s %s' % (self.type, self.dumpname)):
         outline.append(line)
         match = ptn_install_pde.search(line)
         if match:
            raise Exception(match.group(1))

         match = ptn_os_ver_err.search(line)
         if match:
            raise Exception(match.group(1))

         if self.type == 'dbs' and 'Debugging session already in progress' in line:
            raise Exception('Debugging session already in progress')

      return outline

   def attach_dbs(self, hostname):
      self.type     = 'dbs'
      return self.attach_dump(hostname)

   def attach_rawdump(self, dumpname):
      self.type     = 'raw'
      return self.attach_dump(dumpname)

   def info_raw(self):
      raw_dump = []
      for line in self.run_cmd('info raw'):
         if 'No dumps found' in line:
            break
         elif ('FAILURE' in line
               or len(line.strip()) == 0
               or 'is not a dump' in line
               or '(gdb)' in line):
            continue
         raw_dump.append(line.rstrip())
      return raw_dump

   def run_cmd(self, cmd, echo=True):
      p = self.subp

      # Iterate the generator till the last 
      # to make sure the previous command completed.
      for i in self.out_gnrtr: pass

      if echo:
         echostr = '(gdb) ' + cmd 
         if self.m_to_stdout:
            sys.stdout.write( echostr + '\n' )
         self.log(echostr)

      p.stdin.write( cmd + '\n' )
      p.stdin.write( 'shell echo END_OF_COMMAND\n' )
      p.stdin.flush()

      self.out_gnrtr = self._read_gdbout(cmd)
      return self.out_gnrtr

   def _read_gdbout(self, cmd, breakpoint=False):
      # return generator to read gdb output till END_OF_COMMAND
      p = self.subp
      connection_closed = False
      for line in iter(p.stdout.readline, ''):
         p.stdout.flush()

         if ('END_OF_COMMAND' in line
            or 'Continuing.' in line):
            break

         if self.m_to_stdout:
            sys.stdout.write(line)
   
         self.log(line.rstrip())

         if (cmd != 'quit' 
             and 
               (('at dump ' not in cmd # 'connection closed' is sometimes returned when attaching dump
                 and 'at raw '  not in cmd
                 and 'debugging connection closed' in line)
               or ('A problem internal to GDB has been detected' in line))
             ):
            connection_closed = True

         yield line
      # End of for. 
      if connection_closed:
         raise tdgdb.ConnectionClosed()
     
      return 


   def get_backtrace(self, context=None):
      if context:
         self.run_cmd('@ ' + context)

      bt = backtrace()
      bt.parse( self.run_cmd('bt') )
 
      return bt

   def set_frame(self, framenum):
      return self.run_cmd('f ' + str(framenum))

     

   def get_active_thread(self):
      thds = DBSThreads()
      
      cur_part = ''
      for line in self.run_cmd('info ac'):
        match = re.search(r'([a-z_]+):', line)
        if match:
          cur_part = match.group(1)

        for thd in re.findall(r'\d+//\d+', line):
          procnum, thdid   = thd.split('//')
          thdobj           = DBSThread(thdid)
          thdobj.vprocnum  = procnum
          thdobj.active    = True
          thdobj.partition = cur_part
          
          thds.add_thread(thdobj)
      return thds

   def get_alloc_code(self, alloc_addr, context=None):
      if not alloc_addr: return False

      if context:
         self.run_cmd('@ ' + context)

      ptn_codeline = re.compile(r'([^\s\/\(\)]+:\d+)')
      code_line    = None
      for line in self.run_cmd('list *' + alloc_addr):
         match = ptn_codeline.search(line)
         if match:
            code_line = match.group(1)
            break

      if not code_line:
         ptn_codeline2 = re.compile(r'<(\S+)\+\d+>')
         for line in self.run_cmd('p/a ' + alloc_addr):
            match = ptn_codeline2.search(line)
            if match:
               code_line = match.group(1)
               break

      return code_line 


   def quit(self):
      self.run_cmd('quit')

   def __del__(self):
      if (self.auto_quit
          and self.subp):
         self.quit()
      if self.subp:
         self.subp.terminate()


class csppeek(ExternalUtil):
  def __init__(self, dumpname=None, host=None, user=None, pw=None):
    super(csppeek, self).__init__('csppeek')
    self.dumpname        = dumpname
    self.host            = host    
    self.user            = user    
    self.pw              = pw      
    self.can2            = False  # If csppeek2 is available or not
    self.num_node_upld   = 0
    self.num_node_saved  = 0
    self.auto_quit       = False
    self.vcfg            = None

    if os.access('/usr/bin/csppeek2', os.X_OK):
      self.cmd  = ['/usr/bin/csppeek2']
      self.can2 = True
    else:
      self.cmd  = ['/usr/pde/bin/csppeek', '-i', '-d']

  def set_dump(self, dumpname):
    self.dumpname  = dumpname

  def run(self):
    if not self.dumpname:
      return False

    self.cmd.append(self.dumpname)

    if not self.can2:
      if not self.user or not self.pw or not self.host:
         raise Exception('User/password/hostname of dump server needs to be set before running csppeek!')
      self.cmd.extend(['-h', self.host, '-l', self.user, '-p', self.pw])

    self.subp = self.startproc(self.cmd)

    outline   = []
    cur_node  = None
    self.vcfg = Vconfig()
    self.node = {}  # Key: NodeVprNo, Values: TPANode object
    for line in iter(self.subp.stdout.readline, ''):
      outline.append(line)
      self.log(line)

      if 'Table <%s> does not exist' % self.dumpname in line:
        raise Exception('Table <%s> does not exist' % self.dumpname) 

      match = re.search(r'contains (\d+) node', line)
      if match:
        self.num_node_saved = match.group(1)

      match = re.search(r'NODE (\d+) is system (\S+)', line)
      if match:
        if self.node.get(match.group(1)):
           nodeobj = self.node.get(match.group(1))
           nodeobj.hostname = match.group(2)
        else:
           nodeobj = TPANode(match.group(1))
           nodeobj.hostname = match.group(2)

      match = re.search(r'node (\d+) contains vprocs', line)
      if match:
        cur_node = match.group(1)
        self.num_node_upld += 1

      match = re.search(r' (\d+)\(([0A-Z])\)', line)
      if cur_node and match:
        proc_num    = match.group(1)
        vprc        = Vproc(proc_num)
        vprc.type   = match.group(2)
        vprc.nodeid = cur_node
        self.vcfg.vproc_dict[proc_num] = vprc

        if self.node.get(cur_node):
           nodeobj = self.node[cur_node]
           nodeobj.vproclist.append(vprc)
        else:
           nodeobj = TPANode(cur_node)
           nodeobj.add_vproc(vprc)
           self.node[cur_node] = nodeobj

    # end of csppeek output       
    self.subp.terminate()
    self.subp = None

    return outline
  # End of run()

  def get_vconfig(self):
    return self.vcfg


# End of csppeek class
