#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  X.XX (being developed)

 Description:
  Provide API to handle relation format data which
  has row and column.
  e.g. table

"""
version='1.00'

import sys 
import re

class RowBuilder(object):
   def __init__(self, separator=None):
      self.separator = separator   # Required.
      self.starttag      = None
      self.inc_starttag  = False
      self.endtag        = None
      self.inc_endtag    = False
      self.strip_chr     = ' '
      self.row_list      = []
      self.rowhdr        = None
      self.ptn_rowhdr    = None
      self.rowtrlr       = None
      self.ptn_rowtrlr   = None

      self.max_row   = None   # Max number of rows
      self.max_col   = None   # Max number of columns

   def set_starttag(self, regex_starttag, inc_starttag=False):
      self.starttag      = regex_starttag
      self.inc_starttag  = inc_starttag
      self.ptn_starttag  = re.compile(regex_starttag)
   
   def set_endtag(self, regex_endtag, inc_endtag=False):
      self.endtag      = regex_endtag
      self.inc_endtag  = inc_endtag
      self.ptn_endtag  = re.compile(regex_endtag)

   # Set character to be stripped from each column value
   def set_strip_chr(self, strip_chr):
      self.strip_chr   = strip_chr

   # Set row header to be ignored 
   def set_rowhdr(self, regex_rowhdr):
      self.rowhdr      = regex_rowhdr
      self.ptn_rowhdr  = re.compile(r'^' + regex_rowhdr.lstrip('^'))

   # Set row trailer to be ignored 
   def set_rowtrlr(self, regex_rowtrlr):
      self.rowtrlr     = regex_rowtrlr
      self.ptn_rowtrlr = re.compile(regex_rowtrlr.rstrip('$') + r'$')

   def set_separator(self, separator):
      self.separator = separator
   
   def set_input(self, input):
      if isinstance(input, file):
         self.input = iter(input.readline, '')
      elif isinstance(input, list):
         self.input = input


   def get_generator(self):
      start = True
      if self.starttag:
         start = False

      numrow = 0
      for line in self.input:
         if (self.ptn_starttag
            and self.ptn_starttag.search(line)):
            start = True
            if not self.inc_starttag:
               continue

         if (self.ptn_endtag
            and self.ptn_endtag.search(line)):
            start = False
            if not self.inc_endtag:
               continue

         if not start:
            continue 

         # Now, we're at the row to be processed

         if self.ptn_rowhdr:
            line = self.ptn_rowhdr.sub('', line)

         if self.ptn_rowtrlr:
            line = self.ptn_rowtrlr.sub('', line)

         row     = Row()
         for col_val in line.rstrip().split(self.separator):
            if self.strip_chr is None:
               row.col_list.append(col_val)
            else:
               row.col_list.append(col_val.strip(self.strip_chr))

         yield row
      raise StopIteration

   def get_num_row(self):
      return len(self.row_list)

class Row(object):
   def __init__(self):
      self.col_list = []

   def get_num_col(self):     # Return # of columns
      return len(self.col_list)

   def get_col_val(self, col_no=None):
      if col_no is None:
         return self.col_list

      try:
         return self.col_list[col_no]
      except IndexError:
         return False
      

def main():
   if len(sys.argv) == 1:
      sys.exit(0)

   file = sys.argv[1]
   with open(file) as f:

      rl = RowBuilder()
      rl.set_starttag('-----------------')
      rl.set_endtag(r'^(?:\d:)?\s*$')
      rl.set_rowhdr(r'\d:')
      rl.set_strip_chr(r' ')
      lines = f.readlines()  
      rl.set_input(lines)
      #rl.set_input(f)

      g = rl.get_generator()

      while True:
         try: 
            row = next(g)
            print row.col_list
         except StopIteration:
            print('Done ')
            break
    
if __name__ == '__main__':
   main()
