#! /usr/bin/python
"""
 History:
  07Nov2020 ym186001  1.00 Initial release

 Description:
  Provide API so Python script can handle TPA related data

"""
version='1.00'

import sys, os, time
import re


class TPANode(object):
   def __init__(self, nodeid=None):
      self.nodeid      = nodeid # node vproc#
      self.mppname     = None
      self.hostname    = None
      self.vproclist   = []

   def get_nodeid(self):
      return self.nodeid

   def get_hostname(self):
      return self.hostname

   def get_vproclist(self):
      return self.vproclist

   def add_vproc(self, vproc):
      return self.vproclist.append(vproc)

