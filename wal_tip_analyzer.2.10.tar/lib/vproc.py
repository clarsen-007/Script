#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release
  07Jan2020 ym186001  1.10 Added get_num_vproc()
  15Jan2021 ym186001  1.20 Added get_fb_ampno(), get_max_clust()
  28Apr2022 ym186001  1.30 Not run _get_status_compact() when get_status() is called with vproc#

 Description:
  Provide API so Python script can handle vproc related operation
  such as vprocmanager

"""
version='1.30'

import sys, os, time
import re

from extutil import ExternalUtil  # super class

# pattern for 'status' output
ptn_st = re.compile( r'^\s*(\d+)\*?\s+(\d+)\s+(\S+)\s+(\S+)\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)' )
ptn_ctrl_amp = re.compile(r'(\d+)\*')

"""
# Sample status output
Vproc  Rel.   Node    Can   Crash Vproc   Config   Config Cluster/ Host  TVS
Number Vproc# ID      Move  Count State   Status   Type   Host No. Type  Vproc
------ ------ ------  ----- ----- ------- -------- ------ -------- ----- -----
    0*    1     1-01  Yes     0   ONLINE  Online    AMP       0    On    28671
--------------------------------------------------------------------------------

"""

class vprocmanager(ExternalUtil):
   """
   API for python script to operate vprocmanager.

   """
   def __init__(self):
      """
      Parameters

      """
      super(vprocmanager, self).__init__('vprocmanager')
      self.path        = '/usr/tdbms/bin/vprocmanager'
      self.status_file = None  # file which has output of "status" command 
      self.numlf       = 2     # Number of LF to return prompt
      self.vproc_dict  = {}    # Key: vproc#(str) Value: Vproc object
      self.ctrl_amp    = None
      self.no_compact  = True  # suppress compact display(deprecated)

      self.to_stdout(False)

      self.subp = self.startproc(self.path)
      self.subp.stdout.flush()

   @staticmethod
   def vprocstr2list(vprc_str):
      """
      Input:   vprc_str (format: #,#-#  e.g. 1,7-9,20)
      Returns: vproc# list (each vproc# is str)
      """
      vprc_list = []
      ptn_num       = re.compile(r'^\d+$')
      ptn_num_range = re.compile(r'^\d+-\d+$')

      for v in vprc_str.replace(' ', '').split(','):
         if ptn_num_range.search(v):
            lv, hv = v.split('-')
            for v in range(int(lv), (int(hv)+1)):
               v = str(v)
               if not v in vprc_list:
                  vprc_list.append(v)
         elif ptn_num.search(v):
            if not v in vprc_list:
               vprc_list.append(v)

      return vprc_list

   # return control amp as str
   def get_ctrl_amp(self):
      return self.ctrl_amp

   def set_numlf(self, numlf=2):
      self.numlf = numlf

   def set_status_file(self, status_file):
      self.status_file = status_file

   def run_cmd(self, cmd):
      """
      Run vprocmanager command and read the output till next prompt.

      vprocmanager returns prompt tricky: 

        Enter a command, HELP or QUIT:  << prompt#1
        cmd1

        Enter a command, HELP or QUIT:  << prompt#2
        cmd2

      prompt#2 is not returned after cmd1 until cmd2 is entered.
      So this method runs extra LF after the command to return prompt.
      e.g. Enter extra LF after cmd1 to return prompt#2 

      """
      p   = self.subp
      cmd  = cmd.rstrip()
      cmd += '\n' * self.numlf 
      p.stdin.write(cmd) # always enter 2 LFs
   
      out_line   = []
      prpt_found = 0
      for line in iter(p.stdout.readline, ''):
         self.m_to_stdout and sys.stdout.write(line)
         out_line.append(line)
         if 'Enter a command' in line:
            prpt_found += 1
            if prpt_found >= 2:
               return out_line
      

   def _get_status_noncompact(self):
      """ 
      run status command in normal display
      this is deprecated as vprocmanager may get hung.
      """
      return self.get_status('0 to 30719')

   def _set_online_vproc(self, vcfg, vprcstr, crashcnt, clust_node, section):
      """
      Set status for online vproc in compact display.
      
      """
      for vprcno in self.vprocstr2list(vprcstr):
         if section == 'on_amp_pe_by_node':
            # 'ONLINE AMP and PE Vprocs ordered by Node ID' section
            vprc        = vcfg.get_vproc(vprcno)
            vprc.nodeid = clust_node
            continue

         # We're in 'ONLINE AMP Vprocs ordered by Cluster No' section
         #  or 'ONLINE TVS Vprocs ordered by Node ID' section
         vprc          = Vproc(vprcno)
         vprc.type     = 'TVS'
         if section == 'on_amp_by_clust':
            vprc       = AMP(vprcno)
         vprc.crashcnt = crashcnt
         vprc.state    = 'ONLINE'
         vprc.status   = 'Online'
         vprc.clust_host_no = clust_node

         vcfg.vproc_dict[vprcno] = vprc
         if section == 'on_tvs_by_node':
            vprc.nodeid = clust_node
            continue

         # We're in 'ONLINE AMP Vprocs ordered by Cluster No' section
         if vprc.clust_host_no in vcfg.clust_dict:
            vcfg.clust_dict[vprc.clust_host_no].append(vprc)
         else:
            vcfg.clust_dict[vprc.clust_host_no] = [vprc]
      # End of for

      return vcfg

   def _get_status_compact(self, status_list):
      """
      Input:    "status" command output(compact display)
      Returns:  Vconfig object

      """
      vcfg        = Vconfig()
      section     = ''
      ctrl_ampno  = None
      for line in status_list:
         if   'NOTONLINE AMP Vprocs ordered by' in line:
            section = 'noton_amp_by_clust'
         elif 'NOTONLINE PE Vprocs ordered by' in line:
            section = 'noton_pe_by_host'
         elif 'NOTONLINE AMP and PE Vprocs ordered by Node ID' in line:
            section = 'noton_amp_pe_by_node'
         elif 'NOTONLINE TVS Vprocs ordered by Node ID' in line:
            section = 'noton_tvs_by_node'
         elif 'ONLINE AMP Vprocs ordered by' in line:
            section = 'on_amp_by_clust'
         elif 'ONLINE PE Vprocs ordered by' in line:
            section = 'on_pe_by_host'
         elif 'ONLINE AMP and PE Vprocs ordered by Node ID' in line:
            section = 'on_amp_pe_by_node'
         elif 'ONLINE TVS Vprocs ordered by Node ID' in line:
            section = 'on_tvs_by_node'
         elif 'DBS State' in line:
            break

         if section == '':
            continue
         if not re.search(r'\d', line):
            continue   

         match = ptn_ctrl_amp.search(line)
         if match:
            ctrl_ampno = match.group(1)
            line       = re.sub(r'\*', '', line)


         """
         In compact display, # of fields is inconsistent for each line.
         e.g.
         
         Vproc-Ids                  Crash  Can      Host    Host
         Range                       Cnt   Move    Number   Type
         --------------------------  ---  -------  ------  ------
         30541-30542, 30544-30545     0     Yes        1   COP
         30549                        0     No       220   IBM
         30543, 30546                 0     No       420   IBM

         >>> Remove white space which follows comma(,) as follows:        

         Vproc-Ids                  Crash  Can      Host    Host
         Range                       Cnt   Move    Number   Type
         --------------------------  ---  -------  ------  ------
         30541-30542,30544-30545     0     Yes        1   COP
         30549                        0     No       220   IBM
         30543,30546                 0     No       420   IBM
 
         >>> And then, each line has the same # of fields(5 in this sample)
         """
         line = re.sub(r',\s+', ',', line)

         item = line.split()
         if section == 'noton_amp_by_clust':
            if len(item) != 5:
               continue
            for ampno in self.vprocstr2list(item[0]):
               amp          = AMP(ampno)
               amp.crashcnt = item[1]
               amp.state    = item[2]
               amp.status   = item[3]
               amp.clust_host_no = item[4]

               if amp.clust_host_no in vcfg.clust_dict:
                  vcfg.clust_dict[amp.clust_host_no].append(amp)
               else:
                  vcfg.clust_dict[amp.clust_host_no] = [amp]
               vcfg.vproc_dict[ampno] = amp

         elif section == 'noton_pe_by_host':
            if len(item) != 7:
               continue
            for peno in self.vprocstr2list(item[0]):
               pe          = Vproc(peno)
               pe.type     = 'PE'
               pe.crashcnt = item[1]
               pe.canmove  = item[2]
               pe.state    = item[3]
               pe.status   = item[4]
               pe.clust_host_no = item[5]
               pe.hosttype = item[6]
               vcfg.vproc_dict[peno] = pe

         elif section == 'noton_amp_pe_by_node':
            if len(item) != 5:
               continue
            for prcno in self.vprocstr2list(item[0]):
               vproc = vcfg.get_vproc(prcno)
               vproc.nodeid = item[4]

         elif section == 'noton_tvs_by_node':
            if len(item) != 5:
               continue
            for tvsno in self.vprocstr2list(item[0]):
               tvs          = Vproc(tvsno)
               tvs.type     = 'TVS'
               tvs.crashcnt = item[1]
               tvs.state    = item[2]
               tvs.status   = item[3]
               tvs.nodeid   = item[4]
               vcfg.vproc_dict[tvsno] = tvs

         elif section == 'on_amp_by_clust':
            if len(item) != 6:
               continue
            self._set_online_vproc(vcfg, item[0], item[1], item[2], section)
            self._set_online_vproc(vcfg, item[3], item[4], item[5], section)

         elif section == 'on_pe_by_host':
            if len(item) != 5:
               continue
            for peno in self.vprocstr2list(item[0]):
               pe          = Vproc(peno)
               pe.type     = 'PE'
               pe.crashcnt = item[1]
               pe.canmove  = item[2]
               pe.state    = 'ONLINE'
               pe.status   = 'Online'
               pe.clust_host_no = item[3]
               pe.hosttype = item[4]
               vcfg.vproc_dict[peno] = pe

         elif section == 'on_amp_pe_by_node':
            if len(item) != 6:
               continue
            self._set_online_vproc(vcfg, item[0], item[1], item[2], section)
            self._set_online_vproc(vcfg, item[3], item[4], item[5], section)

         elif section == 'on_tvs_by_node':
            if len(item) != 6:
               continue
            self._set_online_vproc(vcfg, item[0], item[1], item[2], section)
            self._set_online_vproc(vcfg, item[3], item[4], item[5], section)
      # End of for loop

      vcfg.ctrl_amp = vcfg.get_vproc(ctrl_ampno)

      return vcfg

   def get_status(self, vproc=''):

      """ 
      Input:   vproc# for which we get status. Get all vprocs if omitted.
               When self.status_file is set, get status from the file.
      Returns: Vconfig object      

      """
      
      vcfg        = Vconfig()
      vproc_dict  = {}
      match       = None
      status_list = []
      if self.status_file:
         f           = open(self.status_file ,'r')
         status_list = f.readlines()
         f.close()
      else:
         status_list = self.run_cmd('status %s' % vproc)

      if list(filter(lambda x: 'compact display will be used' in x , status_list)) and not vproc:
         #Compact display is triggered when # of PE+AMP is over 1024.

         #if self.no_compact:
         #   # suppress compact mode(note it takes 1~2 sec)
         #   return self._get_status_noncompact()
         return self._get_status_compact(status_list)

      for line in status_list:

         match = ptn_st.search(line)
         if match: 
            vprc_num      = match.group(1)
            vprc          = Vproc(vprc_num)
            if match.group(8) == 'AMP':
               vprc       = AMP(vprc_num)

            vprc.type     = match.group(8)
            vprc.nodeid   = match.group(3)
            vprc.crashcnt = match.group(5)
            vprc.state    = match.group(6)
            vprc.status   = match.group(7)
            vprc.clust_host_no = match.group(9)

            match2 = ptn_ctrl_amp.search(line)
            if match2:
               self.ctrl_amp = vprc
               vcfg.ctrl_amp = vprc
            
            if vprc.type == 'AMP':
               if vprc.clust_host_no in vcfg.clust_dict:
                  vcfg.clust_dict[vprc.clust_host_no].append(vprc)
               else:
                  vcfg.clust_dict[vprc.clust_host_no] = [vprc]

            vproc_dict[vprc_num]      = vprc
            vcfg.vproc_dict[vprc_num] = vprc   

      self.vproc_dict = vproc_dict

      return vcfg

   def quit(self):
      if self.subp:
         if self.debug:
            print('vprmgr PID: %d', self.subp.pid)
         self.subp.stdin.write('quit\n')
         self.subp.terminate()
         self.subp = None

   def __del__(self):
      self.quit()

      return
# End of vprocmanager class

class Vconfig(object):
   def __init__(self):
      self.ctrl_amp   = None
      self.vproc_dict = {}  # Key: vproc#(str)  Value: Vproc object
      self.clust_dict = {}  # Key: clust#(str)  Value: list with Vproc objects
      self.node_dict  = {}  # Key: node#(str)   Value: node name(hostname)

   def get_vproc(self, vproc_num=None):
      """
      Input : vproc#(int or str) or None
      Return: Vproc object. all Vprocs returned as list when input is None

      """
      if vproc_num is not None:  # vproc_num can be 0(False for "if")
         return self.vproc_dict.get(str(vproc_num))
      return sorted(self.vproc_dict.values(), key=lambda x: int(x.num))

   def get_max_clust(self):
      max_clust_size = 0
      for clustno in self.clust_dict.keys():      
         if len(self.clust_dict[clustno]) > max_clust_size:
            max_clust_size = len(self.clust_dict[clustno])
      return max_clust_size

   def add_vproc(self, vproc):
      self.vproc_dict[vproc.num] = vproc

   def add_nodeid(self, nodeid):
      if self.node_dict.get(nodeid):
         return # we already have
      self.node_dict[nodeid] = {}

   def get_nodeid(self):
      return self.node_dict.keys()

   # Return Amp objects as list
   def get_amp_in_clust(self, clust_num):
      return self.clust_dict.get( str(clust_num) )

   # Return Amps as list
   def get_amp_on_nodeid(self, nodeid):
      amp_list = [] 
      for vprc in self.vproc_dict.values():   
         if (vprc.nodeid  != nodeid
             or vprc.type != 'AMP'):
            continue 
         amp_list.append(vprc)
      return sorted(amp_list, key=lambda x: int(x.num))

   # Return Control AMP(AMP object)
   def get_ctrl_amp(self):
      return self.ctrl_amp

   # Return FB amps as list(there may be multile FB amps)
   def get_fb_amp(self, ampno, return_num=False):
      ampno    = str(ampno)
      amp      = self.get_vproc(ampno)
      fb_list  = []

      if amp is None:
         return fb_list  # We don't have FB AMP info

      if amp.type != 'AMP':
         return False  # This is not AMP

      clust_no = amp.get_clust_no()
      for tmp_amp in self.get_amp_in_clust(clust_no):
         if ampno == tmp_amp.get_vprocnum():  # not return itself
            continue
         if return_num:
            fb_list.append(tmp_amp.get_vprocnum())
         else:
            fb_list.append(tmp_amp)
      return fb_list

   
   # Return FB amp# as list(there may be multile FB amps)
   def get_fb_ampno(self, ampno):
      return self.get_fb_amp(ampno, True)

   def get_num_vproc(self, nodeid=None):
     # Return: # of vprocs(int). All vprocs by default
     num_vproc = 0
     for vprc in self.vproc_dict.values():
       if nodeid and nodeid != vprc.nodeid:
         continue
       num_vproc += 1
     return num_vproc   

   def get_max_ampno(self):
      max_ampno = 0
      for vproc in self.vproc_dict.values():
         if vproc.type != 'AMP':
            continue
         if vproc.num > max_ampno:
            max_ampno = vproc.num      
      return max_ampno


class Vproc(Vconfig):
   def __init__(self, vproc_num):
      super(Vproc, self).__init__()
      self.num      = vproc_num
      self.nodeid   = None
      self.crashcnt = None
      self.canmove  = None
      self.state    = None
      self.status   = None
      self.type     = None  # vproc type. e.g. AMP, PE, GTW
      self.clust_host_no  = None

   def get_vprocnum(self):
      return self.num   # num is str

   def get_nodeid(self):
      return self.nodeid

   def get_crashcnt(self):
      return self.crashcnt

   def get_state(self):
      return self.state

   def get_status(self):
      return self.status

   def get_type(self):
      return self.type

   def get_clust_host_no(self):
      return self.clust_host_no

class AMP(Vproc):
   def __init__(self, vproc_num):
      super(AMP, self).__init__(vproc_num)
      self.type  = 'AMP'

   def get_clust_no(self):
      return self.clust_host_no

