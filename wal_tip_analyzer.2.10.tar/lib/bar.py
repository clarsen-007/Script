#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 (being developed)

 Description:

"""
version='1.00'

import sys, os
import re
import datetime

from extutil import ExternalUtil 
from cnsutil import cnstool 

barlog_dir='/var/opt/teradata/tdtemp/bar'

class DSAJob(object):

  def __init__(self):
     self.name   = None
     self.jobid  = None
     self.type   = None


class DSAJobExecution(DSAJob):
  def __init__(self):
     super(DSAJobExecution, self).__init__()
     self.execid = None
     self.part   = None       # Partition No.
     self.master_proc = None   
     self.master_node = None  
     self.s_time = None       # datetime obj for job starttime
     self.e_time = None       # datetime obj for job endtime
     self.dsc    = None

class DSLLogParser(object):
  # job type is defined in dsmjob.h
  job_type = { '0' : 'UNKNOWN', 
               '1' : 'EXECUTE',  
               '2' : 'DISCOVERAMPS',  
               '3' : 'ABORT',  
               '4' : 'CHECKSTATUS',  
               '5' : 'OBJECTRELEASE',  
               '6' : 'SETSTATUS',  
               '7' : 'DELETEDSC',  
  }

  # Pattern to get job info from DSL log
  ptn_job_rcv   = re.compile(r'DSMAIN received ActiveMQ Msg: '
                     + 'job_type = (\d+), '
                     + 'job_name = (\S+), '
                     + 'job_id = (\d+), ' 
                     + 'job_execution_id = (\d+), '
                     + 'bucketnumber = 1, DSC = (\S+)')

  ptn_job_start = re.compile(r'DSMAIN starting processes for: '
                     + 'job_type = (\d+), job_id = (\d+), '
                     + 'job_execution_id = (\d+),'
                     + '.*MasterVProc = (\d+) \(Node (\d+-\d+)\), '
                     + 'partition = (\d+), DSC = (\S+)')

  ptn_job_end   = re.compile(r'Freed partition = (\d+)')

  def __init__(self):
     je_list = []  # DSAJobExecution object list

  def get_job_exec_info(self, job_id=None, 
                        job_exec_id=None, job_name=None):
     if not self.je_list:
        return False

     je_list = []
     for je in self.je_list:
        if (job_id is not None
           and str(job_id) != je.jobid):
           continue 
        if (job_name is not None
            and job_name.lower() != je.name.lower()):
           continue
        if (job_exec_id is not None
            and str(job_exec_id) != je.execid):
           continue
        je_list.append(je)

     return je_list

  def set_job_exec_info(self, input=None, job_id=None, 
                        job_exec_id=None, job_name=None):
     """
     Return: DSAJobExecution(list)
     Input:  

     """

     opened = False
     if input is None:
        dsllog = collect_dsllog()
        if not dsllog:
           return False
        input  = open(dsllog, 'r')
        opened = True
     elif isinstance(input, file):
        input  = iter(input.readline, '')
     elif os.path.isfile(input):
        input  = open(input, 'r')
        opened = True

     je_list = []
     je_dict = {}  #Key: part# Value: DSAJobExecution object. For work only
     je  = None
     for line in input:
        match = self.ptn_job_rcv.search(line)
        if match:
           jobtype = match.group(1)
           if jobtype != '1':
              continue

           jobname = match.group(2)
           if (job_name is not None
               and job_name.lower() != jobname.lower()):
              continue

           jobid = match.group(3)
           if (job_id is not None
               and str(job_id) != jobid):
              continue
      
           jobexecid = match.group(4)
           if (job_exec_id is not None
               and str(job_exec_id) != jobexecid):
              continue

           je = DSAJobExecution()
           je.name   = jobname
           je.jobid  = jobid
           je.execid = jobexecid
           je.dsc    = match.group(5)

        match = self.ptn_job_start.search(line)
        if je and match:
           je.master_proc = match.group(4)
           je.master_node = match.group(5)
           je.part        = match.group(6)

           datestr, timestr = line.split()[0:2]
           datetimestr = datestr + ' ' + timestr
           datetimeobj = datetime.datetime.strptime(datetimestr, '%Y/%m/%d %H:%M:%S.%f')

           je.s_time   = datetimeobj

           # Save job exec object till it ends.
           # Other job exec can be invoked before that.
           je_dict[je.part] = je

        match = self.ptn_job_end.search(line)
        if match:
           part   = match.group(1)
           end_je = je_dict.get(part)
           if not end_je:
              continue  # We skipped this job

           del je_dict[part]

           datestr, timestr = line.split()[0:2]
           datetimestr = datestr + ' ' + timestr
           datetimeobj = datetime.datetime.strptime(datetimestr, '%Y/%m/%d %H:%M:%S.%f')
           end_je.e_time = datetimeobj
           je_list.append(end_je)
           end_je      = None

     # End of FOR loop

     # Some jobs may not end in the given log
     for je in je_dict.values():
        je_list.append(je)

     if opened:
        input.close()

     self.je_list = je_list
     return je_list


def get_dslnode():
   """
   Return nodeid on which DSL process is running.
   This needs to run on TPA node.
   """
   cmds = ['/usr/pde/bin/psh', 'ps -ef | grep dsmain | grep -v grep']
   p    = ExternalUtil.startproc(cmds)

   dslnode = None
   for line in iter(p.stdout.readline, ''):
      match = re.search(r'<-+\s+(\S+)\s+-+>', line)
      if match:
         dslnode = match.group(1)

      match = re.search(r'(\S+)\s+\(1\):', line)
      if match:
         dslnode = match.group(1)
      
      if re.search(r'dsmain(?:\s*$|\s+start\s+-age)', line):
         break

   return dslnode

def collect_dsllog(target_dir='.'):
   """
   Collect DSL log(BARLog_*40.txt) from DSL node.

   Input:
     target dir(str) - log collection output directory
                       (current directory by default)

   Returns:
     log file name(str) - when successfully collected log
     False              - when failed to collect. 

   """
   dslnode = get_dslnode()
   if not dslnode:
      return False

   cmds = ['/usr/pde/bin/pcl', '-nodes', dslnode, 
           '-sh', r'ls %s/BARLog*40.txt' % barlog_dir]
   p    = ExternalUtil.startproc(cmds)
  
   ptn   = re.compile(r'BARLog.*40.txt')
   match = None
   for line in iter(p.stdout.readline, ''):
      match = ptn.search(line)
      if match:
         break
   p.terminate()

   if not match:
      return False

   dsllog = match.group(0)

   cmds = ['/usr/pde/bin/pcl', '-nodes', dslnode, 
           '-collect', r'%s/%s' % (barlog_dir, dsllog), target_dir ]
   p    = ExternalUtil.startproc(cmds)
   #print p.stdout.readlines()
   p.terminate()

   collected_file = dsllog + '.' + dslnode
   if os.path.isfile(collected_file):
      return collected_file

   return False


class bardsmain(cnstool):
   """
   Start/stop bardsmain using cnstool.

   """
   def __init__(self):
      self.end_msg = 'bardsmain'
      super(bardsmain, self).__init__('bardsmain')
      self.opts    = ''

   # override super method as bardsmain can have startup option
   # (-s, -j, -days, etc)
   def start_util(self):   
      start_cmd = 'start %s' % self.util
      start_cmd += ' %s' % self.opts
      self._run_wndw6(start_cmd, True)

   def set_option(self, opts):
      self.opts = opts  # bardsmain startup option

   def start(self):
      self.end_msg = r'(?:already running|DSMain started|Error)'
      self.set_end_msg()
      return self.run_cmd('')

   def stop(self):
      self.opts = ' -s' 
      self.end_msg = r'(?:DSMain has been stopped|Error)'
      self.set_end_msg()
      return self.run_cmd('')

   def restart(self):
      out_line   = []

      opts = self.opts  # self.opts will be deleted in stop()
      out_line.extend( self.stop() )

      self.wndw = None # Need to reset window number before starting util

      self.opts = opts
      out_line.extend( self.start() )

      return out_line


def main():
   print('DSL node is %s' % get_dslnode())

   #ret = collect_dsllog()
   #print('Collected DSL log: %s' % ret)

   dp = DSLLogParser()
   je_list = dp.set_job_exec_info('BARLog_26620_40.txt')
   for je in je_list:
      print('%s %s %s %s %s %s %s %s' 
           % (je.name, je.jobid, je.execid, je.part, je.master_proc, 
              je.master_node, je.s_time, je.e_time))

   print('\nGetting job execution id: 1400493')
   je_list = dp.get_job_exec_info(job_exec_id=1400493)
   for je in je_list:
      print('%s %s %s %s %s %s %s %s' 
           % (je.name, je.jobid, je.execid, je.part, je.master_proc, 
              je.master_node, je.s_time, je.e_time))
   
   return

if __name__ == '__main__':
   main()
