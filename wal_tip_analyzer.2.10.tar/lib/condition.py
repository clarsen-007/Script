#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  X.XX (being developed)

 Description:
  Handle combination of conditions dynamically(e.g. ANY, ALL and etc)

"""
version='1.00'

import sys 
import re

class Condition(object):

   def __init__(self, id):
      self.id      = id    # ID/name of this condition
      self.match   = None
      self.debug   = False
      self.evalfnc = None

   def set_evalfnc(self, f):
      self.evalfnc = f

   def evaluate(self, *args, **kwargs):
      """
      Evaluate this condition is True/False using the passed function
      """
      if not callable(self.evalfnc):
         return

      if self.match == True:
         return # Not evaluated again until reset

      if self.evalfnc(*args, **kwargs):
         self.match = True
      else:
         self.match = False

   def is_match(self):
      return self.match

   def set_match(self, trueorfalse):
      self.match = trueorfalse

   def get_cond_tree(self, hdr=''):
      #print('%s%s(%s)' % (hdr, self.id, self.match))
      out_line = []
      out_line.append('%s%s(%s)' % (hdr, self.id, self.match))
      return out_line
      

class Conditions(Condition):
   class DuplicateID(Exception):
      pass

   def __init__(self, id):
      super(Conditions, self).__init__(id)
      self.id_list = []  # condition IDs are sorted by priority
      self.id_dict = {}  # Key: condition ID, Value: Condition(s) object
      self.type    = None

   def add_condition(self, new_cond):  # conditions can be nested
      if not isinstance(new_cond, Condition):
         # Condition's' is also instance of Condition
         return False

      #print('%s is %s' % (condition.id, type(condition)))

      if isinstance(new_cond, Conditions):
         for subcondid in new_cond.id_dict.keys():
            if self.has_id(subcondid):
               raise Conditions.DuplicateID('Condition: %s exists!' % subcondid)

      if self.has_id(new_cond.id):
         raise Conditions.DuplicateID('%s exists!' % new_cond.id)

      self.id_list.append(new_cond.id)
      self.id_dict[new_cond.id] = new_cond

   def has_id(self, id, evaluate=False):
      if id in self.id_dict:
         return True

      for cond in self.id_dict.values():
         if isinstance(cond, Conditions): 
            if cond.has_id(id):
               return True 
      return False

   def evaluate(self, *args, **kwargs):
      """
      Evaluate all conditions including nested ones

      """
      for id in self.id_list:
         cond = self.id_dict[id]
         cond.evaluate(*args, **kwargs)
            

   def evaluate_id(self, id, f, *args, **kwargs):
      if id in self.id_dict:
         # direct sub-condition
         cond = self.id_dict[id]
         if isinstance(cond, Conditions):
            cond.evaluate(id, f, *args, **kwargs)
         else:
            # This is single Condition
            cond.evaluate(f, *args, **kwargs)
         return 

      # Search nested sub-conditions
      for cond in self.id_dict.values():
         if isinstance(cond, Conditions): 
            cond.evaluate(id, f, *args, **kwargs)
      return 
      

   def set_match(self, id, trueorfalse):
      if id in self.id_dict:
         self.id_dict[id].set_match(trueorfalse)
         return 

      for cond in self.id_dict.values():
         if isinstance(cond, Conditions): 
            cond.set_match(id, trueorfalse)

   def get_cond_tree(self, hdr=''):
      node = "%s: %s(%s)" % (self.id, self.type, self.is_match()) 
      #print '%s%s' % (hdr, node)
      out_line = []
      out_line.append('%s%s' % (hdr, node))

      hdr += " " * (len(node) / 2)
      for id in self.id_list:
         cond = self.id_dict[id]
         out_line.extend( cond.get_cond_tree(hdr) )

      return out_line


class ConditionAny(Conditions):
   def __init__(self, id):
      super(ConditionAny, self).__init__(id)
      self.type = 'ANY'

   def is_match(self):
      for id in self.id_list:
         cond = self.id_dict[id]
         if cond.is_match():
            return True
      return False


class ConditionAll(Conditions):
   def __init__(self, id):
      super(ConditionAll, self).__init__(id)
      self.type = 'ALL'

   def is_match(self):
      for id in self.id_list:
         #print('id %s' % id)
         cond = self.id_dict[id]
         if not cond.is_match():
            return False
      return True


def checker(x, y):
   return x > y


def main():

   condA = Condition('A')
   condB = Condition('B')
   condC = Condition('C')
   condD = Condition('D')
   condE = Condition('E')
   condF = Condition('F')

   all1 = ConditionAll('all1')
   all1.add_condition(condA)
   all1.add_condition(condB)
   all1.add_condition(condC)

   any1 = ConditionAny('any1')
   any1.add_condition(condE)
   any1.add_condition(condF)
   
   any2 = ConditionAny('any2')
   any2.add_condition(condD)

   print '====  Set condition A to True'
   all1.set_match('A', True)
   condD.set_match(True)

   print 'A: %s' % condA.is_match()
   print 'B: %s' % condB.is_match()
   print 'C: %s' % condC.is_match()
   print 'all1: %s' % all1.is_match()

   #any1.get_cond_tree()
   any1.add_condition(all1)
   any1.add_condition(any2)
   any1.get_cond_tree()

   print '====  Evaluate condition A'
   condA.set_evalfnc(checker)
   all1.evaluate('A', (1,2))
   
   
   any1.get_cond_tree()

   print '====  Evaluate condition D'
   any2.evaluate('D', checker, 'abc', 'efg')
   for line in any1.get_cond_tree():
      print('DEBUG: %s' % line)

if __name__ == '__main__':
   main()
