#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  X.XX (being developed)

 Description:
  This module provides API so you can easily operate 
  rebuild utility via python script.

"""
version='1.00'

import sys, os
import re
from cnsutil import cnstool  # super class


class rebuild(cnstool):

   def __init__(self):
      super(rebuild, self).__init__('rebuild')
      self.end_msg      = 'Task Exiting'
      self.rebuilt_amp  = []
      self.rebuilt_tbl  = []

   def run_cmd(self, cmd):
      #  - Run 'c' (continue) after each command 
      #  - Ignore if user explicitly runs 'c'
      #  - Not run 'c' after 'quit' command
      out_line = []
      if isinstance(cmd, str):
         cmd = [cmd]

      if not isinstance(cmd, list):
         return False

      for each_cmd in cmd:
         if each_cmd.lower() == 'c':
            continue
         out_line.extend( self.run_each_cmd(each_cmd) )

         if not re.search(r'^\s*quit;?\s*$', each_cmd, re.IGNORECASE):
            out_line.extend( self.run_each_cmd('c') )
      return out_line

   def set_rebuilt_tbl(self, tbl):
      if isinstance(tbl, str):
         self.rebuilt_tbl = [tbl]
      elif isinstance(tbl, list):
         self.rebuilt_tbl = tbl
      else:
        return False

   def set_rebuilt_amp(self, amp):
      if isinstance(amp, str):
         self.rebuilt_amp = [amp]
      elif isinstance(amp, int):
         self.rebuilt_amp = [str(amp)]
      elif isinstance(amp, list):
         self.rebuilt_amp = amp
      else:
        return False

   def run_rebuild(self, data_type):
      if not self.rebuilt_amp:
         return False
      elif not self.rebuilt_tbl:
         return False
 
      out_line = []
      for tbl in self.rebuilt_tbl:
         for amp in self.rebuilt_amp:
            cmd  = 'rebuild amp %s %s %s data' % (amp, tbl, data_type)
            cmd += ';'
            out_line.extend( self.run_cmd(cmd) )

      return out_line

   def run_rebuild_all(self):
      return self.run_rebuild('ALL')

   def run_rebuild_tblhdr(self):
      return self.run_rebuild('TABLE HEADER')

   def run_rebuild_primary(self):
      return self.run_rebuild('PRIMARY')

   def run_rebuild_fallback(self):
      return self.run_rebuild('FALLBACK')

