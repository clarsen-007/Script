#! /usr/bin/python
"""
 History:
  07Nov2020 ym186001  1.00 Initial release

 Description:
  Provide API so Python script can handle DBS thread data structure.
  This has nothing to do with thread for thread programming...

"""
version='1.00'

import sys, os, time
import re

class DBSThreads(object):
   def __init__(self):
      self.thread_dict = {} # Key: vprocnum//threadid  Value: DBSThread obj
   
   def get_thread(self, vprocnum_threadid=None):
      if vprocnum_threadid:
         return self.thread_dict.get(vprocnum_threadid)
      return self.thread_dict.values()

   def get_thdcnt_part(self):
      thdcnt = {}
      for thdobj in self.thread_dict.values():
         part = thdobj.get_partition()
         if thdcnt.get(part):
            thdcnt[part] += 1
         else:
            thdcnt[part] = 1
      return thdcnt

   def add_thread(self, thdobj):
      full_threadid = str(thdobj.get_vprocnum()) + '//' + str(thdobj.get_threadid())
      self.thread_dict[full_threadid] = thdobj

   def get_thread_on_vproc(self, vprocnum):
      thdobj_list = []
      for thdobj in self.thread_dict.values():
         if thdobj.get_vprocnum() == vprocnum:
            thdobj_list.append(thdobj)
      return thdobj_list

   def get_thread_on_partition(self, partition):
      thdobj_list = []
      for thdobj in self.thread_dict.values():
         if thdobj.get_partition() == partition:
            thdobj_list.append(thdobj)
      return thdobj_list

# End of DBSThreads class


class DBSThread(object):
   def __init__(self, threadid=None):
      self.threadid    = threadid 
      self.vprocnum    = None
      self.pid         = None  # PDEPID
      self.partition   = None  
      self.active      = None  
      self.backtrace   = None  
      self.sessionno   = None  
      self.requestno   = None  
      self.segsize     = 0  # Total scratch segment size in byte
      self.segcnt      = 0  # Total scratch segment count

   def get_threadid(self):
      return self.threadid

   def get_full_threadid(self):
      return self.vprocnum + '//' + self.threadid

   def get_vprocnum(self):
      return self.vprocnum

   def get_pid(self):
      return self.pid

   def get_partition(self):
      return self.partition

# End of DBSThread class

class backtrace(object):
   def __init__(self):
      self.func_dict = {}

   def parse(self, input):
      ptn_frame = re.compile(r'#(\d+)\s+0x[0-9a-f]+ in (\S+) ')
      for line in input:
         match = ptn_frame.search(line)
         if match:
            num = match.group(1)
            self.func_dict[num] = match.group(2)

   def get_framenum(self, funcname):
      frame_list = [] 
      for frame in sorted(self.func_dict.keys(), key=lambda x: int(x)):
         if self.func_dict[frame] == funcname:
            frame_list.append(frame)

      return frame_list # same function name may appear multiple times


