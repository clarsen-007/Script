#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:
  Provide API to develop CLI application

"""
version='1.00'

import sys 
import re

class _GetchUnix(object):
   """
   For Unix/Linux OS only
   Returns 1 character from keyboard input raw input.
   """
   def __init__(self):
      import tty, sys, termios # import termios now or else you'll get the Unix version on the Mac

   def __call__(self):
      import sys, tty, termios
      fd = sys.stdin.fileno()
      old_settings = termios.tcgetattr(fd)
      try:
          tty.setraw(sys.stdin.fileno())
          ch = sys.stdin.read(1)
      finally:
          termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
      return ch

class CLI(object):
   """
   This class provides bash like commandline interface. 
   e.g. Up/Down key seeks/displays command history

   """

   ptn_ascii_readable_ch = re.compile(r'[\x20-\x7e]')

   def __init__(self, prompt='> '):
      self.getkey   = _GetchUnix()
      self.cmd_hist = CommandHistory()
      self.cur_pos  = 0
      self.prompt   = prompt

   def replace_cmd(self, new):
      pad_len = len(self.cmd_buf) - len(new)
      pad = ''
      if pad_len > 0: # The existing command is longer than new one. We need to pad white space
         pad = ' ' * pad_len 

      sys.stdout.write('\r%s%s%s' % (self.prompt, new, pad))
      sys.stdout.write('\r' + ('\033[1C' * (len(self.prompt) + len(new)) )) # Set cursor after the new command
      self.cur_pos = len(new)
      self.cmd_buf = new

   def get_command(self):
      self.cmd_buf = ''
      self.cur_pos = 0
      special_key  = None

      self.cmd_hist.set_to_last()
      sys.stdout.write(self.prompt)

      while True:
         k = self.getkey() 

         if special_key is not None:
            special_key += k
            if special_key == '\x1b[A':      # UP key
               special_key = None
               new_cmd = self.cmd_hist.get_prev_cmd()
               if not new_cmd:
                  continue  # This is 1st command. We do nothing 
               self.replace_cmd(new_cmd)

            elif special_key == '\x1b[B':    # Down key
               special_key = None
               new_cmd = self.cmd_hist.get_next_cmd()
               if new_cmd is False:
                  continue  # Currently showing the last command. We do nothing 
               self.replace_cmd(new_cmd)
            elif special_key == '\x1b[D':  # Left key
               special_key = None
               if self.cur_pos == 0:
                  continue
               sys.stdout.write('\033[1D')
               self.cur_pos -= 1
            elif special_key == '\x1b[C':  # Right key
               special_key = None
               if self.cur_pos >= len(self.cmd_buf):
                  continue # Do nothing. We're at the end of line/command
               sys.stdout.write('\033[1C')
               self.cur_pos += 1

         elif self.ptn_ascii_readable_ch.match(k):
            sys.stdout.write(k)
            self.cmd_buf += k
            self.cur_pos += 1
         elif k == '\b':    # Backspace
            if self.cur_pos == 0:
               continue
            self.cur_pos -= 1
            self.cmd_buf = self.cmd_buf[0:self.cur_pos] + self.cmd_buf[self.cur_pos+1:]
            sys.stdout.write('\r%s%s' % (self.prompt, self.cmd_buf + ' '))
            sys.stdout.write('\r' + '\033[1C' * (len(self.prompt) + self.cur_pos))
         elif k == '\r':    # Enter
            sys.stdout.write('\n')
            break
         elif k == '\x1b':  # ESC
            special_key = k
         elif k == '\x03':  # Ctrl + c
            sys.stdout.write('\n')
            raise KeyboardInterrupt

      sys.stdout.flush()
      self.cmd_hist.add(self.cmd_buf)
      return self.cmd_buf

   def print_key(self):
      # Just test purpose
      while True:
         k = self.getkey()
         print('k: ' + repr(k), type(k))
         if k == '\r':
            break

class CommandHistory(object):
   def __init__(self):
      self.hist_list = []
      self.cur_pos   = 0

   def add(self, cmd):
      if cmd == '':
         return
      if (len(self.hist_list) == 0
         or self.hist_list[-1] != cmd):
         self.hist_list.append(cmd)

   def set_to_last(self):
      self.cur_pos = len(self.hist_list)

   def num_cmd(self):
      return len(self.hist_list)

   def get_prev_cmd(self):
      if self.cur_pos == 0:  
         return False
      self.cur_pos -= 1
      return self.hist_list[self.cur_pos]

   def get_next_cmd(self):
      if self.cur_pos == len(self.hist_list):  
         return False
      self.cur_pos += 1
      try:
         next_cmd = self.hist_list[self.cur_pos]
      except IndexError:
         next_cmd = ''
      return next_cmd

ptn_yes = re.compile(r'^(y|yes)$', re.IGNORECASE)
ptn_no  = re.compile(r'^(n|no)$', re.IGNORECASE)

def yon(question):
   """
   Ask yes or no for the question
   """
   while True:
      sys.stdout.write('%s [yes/no]: ' % question)
      sys.stdout.flush()

      ans = sys.stdin.readline().strip()
      if ptn_yes.match(ans):
         return True
      elif ptn_no.match(ans):
         return False
      else:
         sys.stdout.write('Answer yes or no!\n')

def ask(question, default_ans=None):
   """
   Ask question and return the answer as str
   """

   if default_ans:
      question += ' [default=%s]' % default_ans

   sys.stdout.write('%s: ' % question)
   sys.stdout.flush()
   ans = sys.stdin.readline().strip()

   if (not ans 
       and default_ans is not None):
      ans = default_ans

   return ans

def main():
   mycli = CLI()

   while True:
     try:
       cmd = mycli.get_command()
       sys.stdout.write('Command is ' + cmd + '\n')
     except KeyboardInterrupt:
       break


if __name__ == '__main__':
   main()
