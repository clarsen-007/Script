#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release
  06Nov2020 ym186001  1.10 Added dbglog() warnlog() errlog() lognotime()

 Description:
  Logger class works as logging utility for CLI tool.

"""
version='1.00'

import sys, time, os


def now(): return time.strftime('%Y-%m-%d %H:%M:%S')

class Logger(object):

   def __init__(self, debug=None, error=None, warn=None):
      self.logfile     = None
      self.time_suffix = True  # if adding timestamp as suffix to logfile
      self.logfh       = None  # logfile handler instance
      self.hdr         = None  # header for each log line
      self.timetag     = True  # if adding time at beginning of line
      self.striplf     = False # if stripping LF at the end of the log text
      self.m_to_stdout = True  # if write to STDOUT or not
      self.m_del_empty = True  # if deleting empty log file in destructor
      self.ws_aft_hdr  = 2     # Number of white space after log header

      # Setup for each logging level
      if debug:
         self.debug = debug
         if not self.debug.get('to_stdout'):
            self.debug['to_stdout'] = False
         if not self.debug.get('hdr'):
            self.debug['hdr']       = 'DEBUG:'
         if not self.debug.get('timetag'):
            self.debug['timetag']   = False
         if not self.debug.get('timetag'):
            self.debug['striplf']   = True
      else:
         self.debug = { 'to_stdout' : False, 'hdr' : 'DEBUG:', 'timetag' : False, 'striplf' : True }

      if error:
         self.error = error
         if not self.error.get('to_stdout'):
            self.error['to_stdout'] = True
         if not self.error.get('hdr'):
            self.error['hdr']       = 'ERROR:'
         if not self.error.get('timetag'):
            self.error['timetag']   = False
         if not self.error.get('timetag'):
            self.error['striplf']   = True
      else:
         self.error = { 'to_stdout' : True, 'hdr' : 'ERROR:', 'timetag' : False, 'striplf' : True  }

      if warn:
         self.warn = warn
         if not self.warn.get('to_stdout'):
            self.warn['to_stdout'] = True
         if not self.warn.get('hdr'):
            self.warn['hdr']       = 'WARNING:'
         if not self.warn.get('timetag'):
            self.warn['timetag']   = True
         if not self.warn.get('timetag'):
            self.warn['striplf']   = True
      else:
         self.warn = { 'to_stdout' : True, 'hdr' : 'WARNING:', 'timetag' : True, 'striplf' : True  }


   def to_stdout(self, to_stdout=True):
      self.m_to_stdout = to_stdout

   # determine if add time_suffix to logfile
   def set_time_suffix(self, time_suffix=True):
      self.time_suffix = time_suffix

   def set_hdr(self, hdr):
      self.hdr         = hdr        

   def set_debug(self, debug=True):
      self.debug       = debug

   def set_timetag(self, timetag=True):
      self.timetag     = timetag

   def set_ws_aft_hdr(self, ws_aft_hdr):
      self.ws_aft_hdr = ws_aft_hdr

   def open_logfile(self, logfile, time_suffix=None):
      if time_suffix is None:
         time_suffix = self.time_suffix
      if time_suffix:
         logfile += time.strftime('_%Y%m%d_%H%M%S')
         logfile += '.log'

      self.logfh   = open(logfile ,'w')
      self.logfile = logfile
      
   def get_logfile(self):
      return self.logfile   # return log filename

   # Set logfile handler.
   # We can share the same logfh(logfile) with other module
   def set_logfh(self, logfh):
      self.logfh   = logfh

   def get_logfh(self):
      return self.logfh

   def log(self, msg_body, timetag=None, to_stdout=None, striplf=None, hdr=None):
      msg_hdr = ''

      if to_stdout is None:
         to_stdout  = self.m_to_stdout

      if striplf is None:
         striplf = self.striplf
      if striplf:
         msg_body = msg_body.rstrip()

      if timetag is None:
         timetag  = self.timetag
      if timetag:
         msg_hdr  = '%s ' % now() 

      if hdr is None:
         hdr      = self.hdr
      if hdr:
         msg_hdr += '%s ' % hdr

      if msg_hdr:
         msg_hdr += ' ' * (self.ws_aft_hdr - 1)

      # msg_body may have multiple lines
      for line in msg_body.split('\n'):
         msg = '%s%s\n' % (msg_hdr, line)
         if to_stdout:
            sys.stdout.write(msg)
            sys.stdout.flush()

         if self.logfh:
            self.logfh.write(msg)
            self.logfh.flush()

   def lognotime(self, msg_body):
      self.log(msg_body, timetag=False)

   def errlog(self, msg_body):
      self.log(msg_body, timetag=self.error['timetag'], to_stdout=self.error['to_stdout'], 
               striplf=self.error['striplf'], hdr=self.error['hdr'])

   def warnlog(self, msg_body):
      self.log(msg_body, timetag=self.warn['timetag'], to_stdout=self.warn['to_stdout'], 
               striplf=self.warn['striplf'], hdr=self.warn['hdr'])

   def dbglog(self, msg_body):
      self.log(msg_body, timetag=self.debug['timetag'], to_stdout=self.debug['to_stdout'], 
               striplf=self.debug['striplf'], hdr=self.debug['hdr'])
      
   def del_empty(self, del_empty=True):
      self.m_del_empty = del_empty

   def __del__(self):
      if (self.m_del_empty
            and self.logfile
            and os.path.isfile(self.logfile) 
            and os.path.getsize(self.logfile) == 0
            and self.logfh):
         self.logfh.close()
         self.logfh = None
         os.remove(self.logfile)
         

def main():
   lg = Logger()

   lg.log('\n3\nline\nlog!\n')

if __name__ == '__main__':
   main()
