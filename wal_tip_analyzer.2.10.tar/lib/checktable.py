#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:
  This module provides API so python script can handle
  checktable utility.

"""
version='1.00'

import sys, os
import re
from cnsutil import cnstool  # super class

class checktable(cnstool):

   def __init__(self):
      super(checktable, self).__init__('checktable')
      self.end_msg    = 'CheckTable terminated'
      # override default prompt('Reading') as checktable returns it
      # shortly after submitting command
      self.prompt_str = 'Enter a command'
      self.tbl_list   = []

   # Set check target table(s)
   def set_table(self, tbl):
      if isinstance(tbl, str):
         self.tbl_list = [tbl]
      elif isinstance(tbl, list):
         self.tbl_list = tbl
      else:
         return False

   def _start(self, level):
      if not self.tbl_list:
         return False

      out_line = []
      for tbl in self.tbl_list:
         cmd  = "check %s at level %s" % (tbl, level)
         cmd += ';'
         out_line.extend( self.run_cmd(cmd) )
      return out_line

   def check_level_one(self):
      self._start('one')

   def check_level_two(self):
      self._start('two')

   def check_level_three(self):
      self._start('three')

   def check_level_pendingop(self):
      self._start('pendingop')

   def check_level_hash(self):
      self._start('hash')

