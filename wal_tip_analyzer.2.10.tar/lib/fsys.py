#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release
  30Sep2020 ym186001  1.10 Add count_row(), tid2name(), name2tid()
  16Oct2020 ym186001  1.11 Fix set_tip_summary_info as this returned tip info from
                           non-latest summary record, too.
  20Jan2021 ym186001  1.20 Add find_subtbl()
  17Mar2922 ym186001  1.30 Support filer local mode 

 Description:
  This module provides API so python script operates
  filer utility and handle FSG objects

"""

import sys, os, time
import re
from cnsutil import cnstool

regex_hex_4chr  = r'([0-9A-F]){4}' 
regex_hex_8chr  = r'([0-9A-F]){8}' 
regex_hex_16chr = r'([0-9A-F]){16}' 

ptn_hex_str  = re.compile(r'[0-9A-F]+') 
ptn_wlsn     = re.compile(r'^[0-9A-F]{16}$') 
ptn_hex_2chr = re.compile(r'([0-9A-F])([0-9A-F])') 

ptn_vprocnum = re.compile('vproc\s+(\d+)\s')
ptn_reclen_wlsn_kind = re.compile(r'(%s)   (%s)\s+(\S+)\s*$' 
          % (regex_hex_8chr, regex_hex_16chr) )

ptn_tid_prnths = re.compile(r'\(\s*([0-9A-F]{4}\s+[0-9A-F]{4}\s+[0-9A-F]{4})\s*\)')
prn_vpr_resp   = re.compile(r'vproc\s+(\d+)\s+\([0-9A-F]{4}\)\s+response')


#----------------------------
# pattern for table header(tab/l output) 
ptn_dbname  = re.compile(r'Database Name\s+:\s+"?([^"\s]+)"?')
ptn_tblname = re.compile(r'Table Name\s+:\s+"?([^"\s]+)"?')
ptn_tid     = re.compile(r'TableID:\s+([0-9A-F]{4})\s+([0-9A-F]{4})')
ptn_dbid    = re.compile(r'DataBase ID\s+:\s+(\d+)\s+(\d+)')
ptn_ctime   = re.compile(r'Created\s+:\s+(\S+ \S+)')
ptn_atime   = re.compile(r'Last Updated\s+:\s+(\S+ \S+)')

#----------------------------
# pattern for WMI

# get WCID and firstwlsn
ptn_wcid = re.compile(r'([0-9A-F]{16})\s+([0-9A-F]{16})\s+[0-9A-F]{2}\s+[0-9A-F]{4}')

#----------------------------
# pattern for MI
ptn_mi = re.compile(r'%s %s %s %s ' 
           % (regex_hex_16chr, regex_hex_4chr, regex_hex_4chr, regex_hex_4chr))

#----------------------------
# pattern for MI/WMI
ptn_freecnt = re.compile(r'FreeCount\s+:\s+(\d+)')
ptn_refcnt  = re.compile(r'RefCount\s+:\s+(\d+)')

#----------------------------
# pattern for checkpoint

ptn_ci_sect_wlsn = re.compile(r'([0-9A-F]{16}) ([0-9A-F]{4}) [0-9A-F]{8} ([0-9A-F]{16})')


#----------------------------
# pattern for ident command
ptn_ident_tid = re.compile(r'\s*[0-9A-F]{4} ([0-9A-F]{4}  [0-9A-F]{4}  [0-9A-F]{4})')

def dec2hex(dec):
   return '{0:x}'.format(int(dec))

def hex2dec(hex_str):
   return int(hex_str, 16)

# End of global info


class filer(cnstool):

   def __init__(self, start_cmd=''):
      super(filer, self).__init__('filer')
      self.end_msg   = 'Filer has exited'
      self.ctrl_amp  = None
      self.opts      = ''     # filer startup option
      self.start_cmd = start_cmd

   @staticmethod
   def tid2list(tid):
      tid_list = []
      if isinstance(tid, str):
         tid_list = tid.split()
      elif isinstance(tid, list):
         tid_list = tid
      else:
         raise Exception('tid must be str or list!\n')

      # remove dot and comma
      tid_list = list(map(lambda x: re.sub(r'[.,]', '', x.strip()), tid_list)) 
      return tid_list

   # Obsolete as we can use join_wndw() method
   def start_util_1(self):
      start_cmd = 'start %s' % self.util

      if self.ctrl_amp:
         start_cmd  = 'start -v %s filer' % self.ctrl_amp
         start_cmd += ' %s' % self.opts
      if self.start_cmd:
         match = re.search(r'start\s+-v\s+(\d+)\s+filer', self.start_cmd)
         if match:
            self.ctrl_amp = match.group(1)
         start_cmd = self.start_cmd

      self._run_wndw6(start_cmd, True)

   def set_local_mode(self, amp):
      # this needs to be called before invoking filer
      self.ctrl_amp  = amp
      self.start_cmd = 'start -v %s filer -v %s' % (str(amp), str(amp))

   # set filer control amp
   def set_ctrl_amp(self, amp):
      self.ctrl_amp = amp

   def set_option(self, opts):
      self.opts     = opts   # filer startup option

   def tid2name(self, tid, is_decimal=False):
      tblhdr  = self.get_tblhdr(tid, is_decimal)
      dbname  = tblhdr.dbname
      tblname = tblhdr.tblname

      return '%s.%s' % (dbname, tblname)

   def name2tid(self, name):
      tid_list = []
      ptn_tid = re.compile(r'TableID:\s+([0-9A-F]{4})\s+([0-9A-F]{4})')
      for line in self.run_cmd('tab/c "%s" 0 *' % name.strip().strip('"')):
        match = ptn_tid.search(line)
        if match:
          tid_list = [match.group(1), match.group(2)]
          return tid_list

   # Return : TableHeader object for the TID
   # Input  : tid - str or list. 
   #          is_decimal - True means the tid is in decimal(default False)  
   def get_tblhdr(self, tid, is_decimal=False):
      tid    = self.tid2list(tid)
      if is_decimal:
         tid = list(map(dec2hex, tid))

      tblhdr = TableHeader()
      tblhdr.set_tblhdr(self.run_cmd('tab/l %s %s 0 *' % (tid[0],tid[1])))
      return tblhdr

   # This method works only when DBS is up and running
   def get_tblhdr_by_name(self, tblname):
      tblname = tblname.strip().replace('"', '')

      tblhdr = TableHeader()
      tblhdr.set_tblhdr( self.run_cmd('tab/l "%s" 0 *' % tblname) )
      return tblhdr

   # Find AMP# which has the specified TID/subtable id in list
   # Caller is responsible to set scope
   def find_subtbl(self, tid, subtbl):
      tid = self.tid2list(tid)

      amp_list = []
      cur_amp  = None
      ptn_tab_c_out = re.compile(r'TableID:.* %s\s+ROWS:' % subtbl.upper().zfill(4))
      for line in self.run_cmd('tab/c %s %s %s *' * (tid[0], tid[1], subtbl)):
         match = ptn_vprocnum.search(line)
         if match:
            cur_amp = match.group(1)

         match = ptn_tab_c_out.search(line)
         if match:
            amp_list.append(cur_amp)
      return amp_list


   def count_row(self, tbl):
      # Count row in subtable 0x400. Scope needs to be set out of this method
      # Input: str - TID or tablename. TID must be followed by . when decimal 
      # Out:   int - Row count
      cnt = 0

      if isinstance(tbl, list):
        tbl = '%s %s' % (tbl[0], tbl[1])

      tbl   = tbl.strip().strip('"')
      match = re.search(r'\S+\.\S+' , tbl)
      if match:
        tbl = '"%s"' % tbl  # Add double quote if input is table name

      ptn_row = re.compile(r' 0400\s+ROWS:\s+([0-9A-F]{16})')
      for line in self.run_cmd('tab/c %s 400 *' % tbl):
        match = ptn_row.search(line)
        if not match:
          continue
        cnt += hex2dec(match.group(1))

      return cnt

   def set_scope(self, scope_str):
      out_line = self.run_cmd('scope %s' % scope_str)
      if not list(filter(lambda x: 'have been selected' in x, out_line)):
         return False
      return out_line

   def get_seg0(self):
      seg0 = SEG0()
      seg0.set_seg0_info( self.run_cmd('seg0') )
      return seg0

   def get_storage(self):
      strg = Storage()
      strg.set_storage_info( self.run_cmd('storage') )
      return strg

   def get_wmi(self):
      wmi = WMI()
      wmi.set_wmi_info( self.run_cmd('wmi/l') )
      return wmi

   def get_wsummary(self):
      wsmry = Wsummary()
      wsmry.set_wsummary_info( self.run_cmd('wsummary') )
      return wsmry

   def get_mi(self):
      mi = MI()
      mi.set_mi_info( self.run_cmd('mi/l') )
      return mi

   def get_checkpoint(self, checkwlsn):
      chkpt = Checkpoint()
      chkpt.set_wlsn_db(self.run_cmd('wrec/x %s' % checkwlsn))
      return chkpt

   def get_ident(self, cid, sect):
      ident = Ident()
      ident.set_ident_info( self.run_cmd('ident %s %s' % (cid, sect))  )
      return ident


# End of filer class

class Table(object):

   def __init__(self):
      self.tid      = []
      self.dbid     = []
      self.dbname   = None
      self.tblname  = None
      self.fallback = None
      self.ctime    = None   # CreateTimestamp
      self.atime    = None   # LastAlterTimestamp

      self.tjcnt    = None   # # of TJ in wsummary
      self.nontjcnt = None   # # of non-TJ in wsummary
      self.cidcnt   = None   # # of CID in MI

   def get_tid(self):
      return self.tid

   def get_dbid(self):
      return self.dbid

   def get_dbname(self):
      return self.dbname

   def get_tblname(self):
      return self.tblname

   def is_fallback(self):
      return self.fallback

   def get_ctime(self):  # ctime: CreateTimestamp
      return self.ctime

   def get_atime(self):  # atime: LastAlterTimestamp
      return self.atime

class TableHeader(Table):

   def __init__(self):
      super(TableHeader, self).__init__()
      self.field4    = None
      self.fathdr    = None
      self.dbname    = None
      self.tblname   = None
      self.tid       = None
      self.dbid      = None
      self.fallback  = None
      self.sparse = False

   def set_tblhdr(self, tab_l_list):
      """
      parse 'tab/l' output for table header and set properties.

      Parameters
       tab_l_list : list  
         output of filer 'tab/l'. 1 element has 1 line
      """

      first_vproc = True
      for line in tab_l_list:
         match = prn_vpr_resp.search(line)
         if match:
            if not first_vproc:
              break
            first_vproc = False

         match = ptn_dbname.search(line)
         if match:
            self.dbname = match.group(1)

         match = ptn_tblname.search(line)
         if match:
            self.tblname = match.group(1)

         match = ptn_tid.search(line)
         if match:
            self.tid = [match.group(1), match.group(2)]

         match = ptn_dbid.search(line)
         if match:
            self.dbid = [match.group(1), match.group(2)]

         match = ptn_ctime.search(line)
         if match:
            self.ctime = match.group(1)

         match = ptn_atime.search(line)
         if match:
            self.atime = match.group(1)

         if 'Protection' in line:
            if 'No' in line:
               self.fallback = False
            else:
               self.fallback = True

         if 'Fat Header' in line:
            if 'FALSE' in line:
               self.fathdr   = False
            else:
               self.fathdr   = True

         if 'Sparse Map Info' in line:
            self.sparse   = True
   # End of set_tblhdr()

   def get_field4(self):
      return self.field4

   def is_fathdr(self):
      return self.fathdr

# End of TableHeader class

class FsysSeg(object):
   def __init__(self):
      self.ampno        = None

   def dbglog(self, msg):
      sys.stdout.write('[debug] %s\n' % msg)
      sys.stdout.flush()

   def get_ampno(self):
      return self.ampno

class MI(FsysSeg):
   def __init__(self):
      super(MI, self).__init__()
      self.ampno        = None
      self.freecount    = None
      self.refcount     = None
      self.timestamp    = None
      self.cid_list     = []   # CID object. Order by TID(same as MI output)
      self.tid_cylcnt   = {}   # Key: TID  Value: # of Cyl for the TID

   def set_mi_info(self, mi_list):
      for line in mi_list:
         match = ptn_vprocnum.search(line)
         if match:
            self.ampno = match.group(1)

         match = ptn_freecnt.search(line)
         if match:
            self.freecount = match.group(1)

         match = ptn_refcnt.search(line)
         if match:
            self.refcount = match.group(1)

         match = ptn_mi.search(line)
         if match:
            if line.lstrip()[1] == ':' :
               line = line[2:]  # Remove cnstool header
            col = line.split()
            cid = CID()
            cid.cid        = col[0]
            cid.firsttid   = [ col[1], col[2], col[3] ]
            cid.firstrid   = [ col[4], col[5], col[6], col[7], col[8] ]
            cid.lasttid    = [ col[9], col[10], col[11] ]
            cid.lastrowkey = [ col[12], col[13], col[14] ]
            cid.fl       = col[15]
            cid.fp       = col[16]
            cid.fsc      = col[17]
            cid.ufsc     = col[18]

            self.cid_list.append(cid)

            tidstr = "%s %s" % (cid.firsttid[0], cid.firsttid[1])
            if tidstr in self.tid_cylcnt:
               self.tid_cylcnt[tidstr] += 1
            else:
               self.tid_cylcnt[tidstr] = 1

   def get_cid_list(self):
      return self.cid_list

   # get CID and its # of Cyls in MI
   # Return value = tuple( tid(str), #ofCyl(int) ) order by #ofCyl
   def get_tid_cylcnt(self):
      return sorted(self.tid_cylcnt.items(), key=lambda kv: (kv[1], kv[0]), reverse=True )


class CID(FsysSeg):  # Cylinder Index Descriptor (not CI)
   def __init__(self, cid=None):
      super(CID, self).__init__()
      self.cid      = cid
      self.firsttid = []
      self.firstrid = []
      self.lasttid  = []
      self.lastrowkey = []
      self.fl       = None
      self.fp       = None
      self.fsc      = None
      self.ufsc     = None
      

class SEG0(FsysSeg):

   def __init__(self):
      super(SEG0, self).__init__()
      self.maxdltblwlsn = None
      self.checkwlsn    = None  # WLSN for checkpoint 

   def set_seg0_info(self, seg0_list):
      for line in seg0_list:
         match = re.search(r'VProcID\s+:\s+(\d+)', line)
         if match:
            self.ampno = match.group(1)

         match = re.search(r'Max Deleteable WLSN :.*\(([0-9A-F]{16})\)', line)
         if match:
            self.maxdltblwlsn = match.group(1)

         match = re.search(r'CheckWLSN.*\(([0-9A-F]{16})\)', line)
         if match:
            self.checkwlsn = match.group(1)
      return

   def get_maxdltblwlsn(self):
      return self.maxdltblwlsn

   def get_checkwlsn(self):
      return self.checkwlsn

class Storage(FsysSeg):

   def __init__(self):
      super(Storage, self).__init__()
      self.large_cyl  = True

   def set_storage_info(self, storage_list):
      for line in storage_list:
         if re.search('Large Cylinders Allocated\s+: 0 ', line):
            self.large_cyl  = False

   def is_large_cyl(self):
      return self.large_cyl

# Filer ident command
class Ident(FsysSeg):

   def __init__(self):
      super(Ident, self).__init__()
      self.dbname  = None
      self.tblname = None
      self.tid     = []
  
   def set_ident_info(self, ident_list):
      for line in ident_list:
         match = ptn_ident_tid.search(line)
         if match:
            self.tid = match.group(1).split()  

         match = ptn_dbname.search(line)
         if match:
            self.dbname = match.group(1)

         match = ptn_tblname.search(line)
         if match:
            self.tblname = match.group(1)

class Wsummary(FsysSeg):

   ptn_total_reccnt = re.compile(r'There is a total of\s+(\d+)')
   ptn_nontj_reccnt = re.compile(r'non-TJ count\s+(\d+)')
   ptn_tj_reccnt    = re.compile(r' TJ count\s+(\d+)')

   def __init__(self):
      super(Wsummary, self).__init__()
      self.tid_list     = []  # [ TID[list], (#ofTJ), (#ofWAL) ]
      self.total_reccnt = None
      self.nontj_reccnt = None
      self.tj_reccnt    = None

   def get_tid_list(self):
      return self.tid_list

   def get_tid_reccnt(self):
      """
      Return # of TJ/non-TJ records per TID as dictionary.
      """
      tid_reccnt_dict = {}
      for tid_reccnt in self.tid_list:
         tid     = tid_reccnt[0]
         tjcnt   = tid_reccnt[1]
         nontjcnt= tid_reccnt[2]
         tid_str = '%s %s' % (tid[0], tid[1])
 
         if tid_reccnt_dict.get(tid_str):
            tid_reccnt_dict[tid_str][1] += tjcnt
            tid_reccnt_dict[tid_str][2] += nontjcnt
         else:
            tid_reccnt_dict[tid_str] = [[tid[0], tid[1]], tjcnt, nontjcnt]
      
      return sorted(tid_reccnt_dict.items(), key=lambda kv: kv[1][1]+kv[1][2])

   def set_wsummary_info(self, wsummary_list):
      for line in wsummary_list:
         match = ptn_vprocnum.search(line)
         if match:
            self.ampno = match.group(1)

         match = self.ptn_total_reccnt.search(line)
         if match:
            self.total_reccnt = match.group(1)

         match = self.ptn_nontj_reccnt.search(line)
         if match:
            self.nontj_reccnt = match.group(1)

         match = self.ptn_tj_reccnt.search(line)
         if match:
            self.tj_reccnt = match.group(1)

         match = ptn_tid_prnths.search(line)
         if match:
            tid  = match.group(1).split()

            line   = cnstool.ptn_cnshdr.sub('', line)
            item   = line.split()
            tjcnt  = int(item[8])
            walcnt = int(item[12])

            self.tid_list.append([tid, tjcnt, walcnt])

         if (self.tid_list
             and re.search('^(?:\d:)?\s*$' ,line)):
             break

class WMI(FsysSeg):

   def __init__(self):
      super(WMI, self).__init__()
      self.timestamp    = None
      self.freecount    = None
      self.refcount     = None
      self.wcid_list    = []    # WCIDs are in order of WLSN
      self.all_wcids    = False # All WCIDs listed i.e. wmi ran with l option
      return

   def set_wmi_info(self, wmi_list):

      for line in wmi_list:
         match = ptn_vprocnum.search(line)
         if match:
            self.ampno = match.group(1)

         match = ptn_freecnt.search(line)
         if match:
            self.freecount = match.group(1)

         match = ptn_refcnt.search(line)
         if match:
            self.refcount = match.group(1)

         if 'All The WCIDs on the WMI' in line:
            self.all_wcids = True

         match = ptn_wcid.search(line)
         if match:
            self.wcid_list.append( {
               'wcid'       : match.group(1) ,
               'firstwlsn'  : match.group(2)
            } )
         
   def get_refcount(self):
      return self.refcount

   def get_freecount(self):
      return self.freecount

   def get_wcid_list(self):
      return self.wcid_list

class WCI(FsysSeg):

   def __init__(self):
      super(WCI, self).__init__()
      self.wcid         = None
      self.firstwlsn    = None
      return


class WALRecord(FsysSeg):

   class Reckind(Exception):
      pass

   def __init__(self):
      super(WALRecord, self).__init__()
      self.wlsn         = None
      self.kind         = None
      return

   def get_wlsn(self):
      return self.wlsn

   def get_kind(self):
      return self.kind

   def is_smaller(self, rec):
      if (isinstance(rec, str)
          and ptn_wlsn.search(rec)): 
         # Input is 16 digit hex string
         return self.get_wlsn() < rec 
      elif callable(rec.get_wlsn):
         # Input is WALRecord object
         return self.get_wlsn() < rec.get_wlsn()
      else:
         return None

class Checkpoint(WALRecord):

   def __init__(self, wlsn=''):
      super(Checkpoint, self).__init__()
      self.wlsn      = wlsn
      self.kind      = 'CHECKPOINT'
      self.redowlsn  = None
      self.min_wlsn  = None
      self.wlsn_dict = {}  # Key: WLSN  Value: list [CID, Sect]

   def set_wlsn_db(self, checkpoint_list):

      record_hdr_dash = False
      for line in checkpoint_list:
         if record_hdr_dash:
            record_hdr_dash = False
            re.sub(r'^\d:', '', line)
            reclen, wlsn, kind = line.split()
            #if kind != 'CHECKPOINT':
            #   raise WALRecord.Reckind('%s is %s, not CHECKPOINT!\n' % (wlsn,kind) )

         if '---------- ---------------- ---------------' in line:
            record_hdr_dash = True
            continue

         match = ptn_ci_sect_wlsn.search(line)
         if match:
            recwlsn = match.group(3)
            cid     = match.group(1)
            sect    = match.group(2)

            self.wlsn_dict[recwlsn] = [cid, sect]
      return

   def get_wlsn_db(self):
      return self.wlsn_dict

   def get_db(self, wlsn):
      return self.wlsn_dict.get(wlsn)

   def get_min_wlsn(self):
      if not self.wlsn_dict:
         return
      return sorted(list(self.wlsn_dict.keys()))[0]

class TIPRecord(WALRecord):

   def __init__(self, wlsn=''):
      super(TIPRecord, self).__init__()
      self.kind         = 'TJRECORD'
      self.wlsn         = wlsn
      self.txnno        = []  
      self.hostno       = ''
      self.sesno        = []
      self.reqno        = []
      self.intreqno     = []

   def get_sesno(self):
      return self.sesno

   def get_hostno(self):
      return self.hostno

   def get_hostno_int(self):
      return int(self.hostno, 16)

   def get_txnno(self):
      return self.txnno  # list. Each number is in hex 

   def get_txnno_str(self):
      txnno_str = '%s %s %s' % (int(self.txnno[0], 16), self.txnno[1], self.txnno[2])
      return txnno_str

   def get_sesno_int(self):
      sesno_hex = ''.join(self.sesno)
      return int(sesno_hex, 16)

   def get_reqno(self):
      return self.reqno

   def get_reqno_int(self):
      reqno_hex = ''.join(self.reqno)
      return int(reqno_hex, 16)

   def get_intreqno(self):
      return self.intreqno

   def get_intreqno_int(self):
      intreqno_hex = ''.join(self.intreqno)
      return int(intreqno_hex, 16)

class TIPSummaryRecord(TIPRecord):

   def __init__(self, wlsn=''):
      super(TIPSummaryRecord, self).__init__()
      self.wlsn         = wlsn
      self.kind         = 'TJRECORD'
      self.tipcnt       = None  
      self.tip_list     = []    # order by WLSN ascend

   def set_tip_summary_info(self, tip_summary_list):
      """
      Parse and set TIP summary record (output of "wrec/l where tjkind=TIP")
      We set from the latest summary record if tip_summary_list has
      multiple summary records,
      """
      tip_list = []
      txnno    = []
      hostno   = ''
      sesno    = ''
      reqno    = ''
      intreqno = ''
      tip_smry_dict = {}  # Key: tip_summary_wlsn  Value: tip_list

      found_newer_summary = True
      #prev_smry_wlsn      = '0000000000000000'
      cur_smry_wlsn       = ''

      for line in tip_summary_list:

         match = re.search(r'([0-9A-F]{16})\s+TJRECORD', line)
         if match:
            cur_smry_wlsn = match.group(1)
            tip_list = list()
            tip_smry_dict[cur_smry_wlsn] = tip_list

            if cur_smry_wlsn > self.wlsn:
               found_newer_summary = True
               self.wlsn      = cur_smry_wlsn
            else:
               found_newer_summary = False

         if not found_newer_summary:
            continue

         #match = re.search(r'TIPCnt:\s+([0-9A-Z]{4})', line)
         #if match:
         #   self.tipcnt = match.group(1)
         #   continue

         match = re.search(r'TranNo:  ([0-9A-F]{4} [0-9A-F]{4} [0-9A-F]{4})', line)
         if match:
            txnno = match.group(1).split()
            continue

         match = re.search(r'Host#([0-9A-F]{4}) Sess#([0-9A-F]{4} [0-9A-F]{4}) Req#([0-9A-F]{4} [0-9A-F]{4}) HReq#([0-9A-F]{4} [0-9A-F]{4})', line)
         if match:
            hostno   = match.group(1)
            sesno    = match.group(2).split()
            intreqno = match.group(4).split()
            reqno    = match.group(3).split()
            continue

         # wlsn may have white space if msw/lsw is less than 8 digits.
         match = re.search(r'StartLoc:\s+0x([ 0-9A-F]{8})([ 0-9A-F]{8})', line)
         if match:
            wlsn  = match.group(1).replace(' ', '0') 
            wlsn += match.group(2).replace(' ', '0') 
         
            tip          = TIPRecord(wlsn)
            tip.txnno    = txnno 
            tip.hostno   = hostno
            tip.sesno    = sesno
            tip.reqno    = reqno
            tip.intreqno = intreqno

            tip_list.append(tip)           
            continue
      # End of for loop

      if len(tip_smry_dict) == 0:
         return False # we found no summary record

      # Find the latest TIP summary record(i.e. largest WLSN)
      latest_smry_wlsn = sorted(tip_smry_dict.keys(), reverse=True)[0]
      tip_list = tip_smry_dict.get(latest_smry_wlsn)

      self.tipcnt = len(tip_list)

      # sort tip entries in order of WLSN 
      tip_list.sort(key=lambda x: x.get_wlsn())  
      self.tip_list = tip_list
   # End of set_tip_summary_info()

   # Returns the oldest TIPRecord in this TIPSummaryRecord
   def get_min_tip(self):
      if self.tip_list:
         return self.tip_list[0]
      else:
         return False

   def get_tip_list(self):
      return self.tip_list

   def get_tipcnt(self):
      return self.tipcnt

def main():

  smry = TIPSummaryRecord()

  f = open('sumry.out' , 'r')
  smry.set_tip_summary_info(f)
  

  print('this summary %s has %d TIP records' % (smry.get_wlsn(), smry.get_tipcnt()) )

  for tip in smry.get_tip_list():
    wlsn  = tip.get_wlsn()
    sesno = tip.get_sesno_int()
    reqno = tip.get_intreqno_int()

    print('Found WLSN %s for session %d request %d'
                           % (wlsn, sesno, reqno))

  f.close()
  return


if __name__ == "__main__":
  main()
