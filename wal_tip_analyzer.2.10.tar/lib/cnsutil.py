#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release
  20Sep2020 ym186001  1.01 Fixed _is_pde_dbs_up() to support the case
                           get_pdestate() returns PDE state only
  22Sep2020 ym186001  1.10 add get_cnscim_s()
                           add join_wndw()
                           run_each_cmd() checks if LF/CRLF in command
  04Oct2020 ym186001  1.20 add run_cmd2(), _wait_prompt2() i.e. generator
                           version.
  17Mar2022 ym186001  1.30 Modified start_util() for filer local mode
  27Apr2022 ym186001  1.40 Bug fix for 1.30.  Added start_cmd in constructor 


 Description:
  Provides API so python script handle cns
  utilities via python script.
  This is intended for utilities like:
  - we need to parse the output and run the next command 
    based on the previous output 
  - we need to type several/many commands during execution
  e.g. filer, lokdisp


"""

import sys, os, time, datetime
import re

from tdutil  import get_pdn, get_pdestate 
from extutil import ExternalUtil  # super class
from timeout import Timeout
from net     import is_valid_hostname


class cnstool(ExternalUtil):
   """
 This class runs cns utilities using cnstool instead of cnsrun.
 Advantages of cnstool are as follows:
 - cnstool is much faster than cnsrun
 - able to operate cns window 6 (e.g. abort session, enable/disable logons)

 But unlike cnsrun, this class needs to parse/read cnstool prompt
 in order to get out of the screen when needed.

   """

   # cns util which immediately ends after start
   start_only_util = ('showlocks','bardsmain')
   # cns util which requires semicolon after each command
   semicolon_util  = ('checktable','rebuild', 'rcvmanager')

   # cns util which can run when DBS is not running yet
   # rcvmanager can run from down AMP recovery phase
   no_dbs_util   = ('filer','rcvmanager')

   # cnstool returns 2 invisible chars after ':' (0x1B is ESC).
   ptn_reading = re.compile( u':\u001B\u0053Reading\s*$' )
   #ptn_prompt  = ptn_reading  # default prompt
   ptn_running = re.compile( u':\u001B\u0053Running' )

   ptn_prt_bsy = re.compile(r'All Interactive Partitions are busy')
   ptn_cnshdr  = re.compile(r'^\d:')

   ptn_cnscim  = re.compile(r'Screen ([1-4])  --  (.*)\s*$')

   ptn_crlf    = re.compile(r'\r?\n')

   @staticmethod
   def get_cnscim_s():
     cmds = ['/usr/pde/bin/cnscim', '-s']
     cimp = ExternalUtil.startproc(cmds)

     cnsscr_dict   = {}
     each_scr_dict = {}
     cur_scr     = None
     for line in iter(cimp.stdout.readline, ''):
       match = cnstool.ptn_cnscim.search(line)
       if match:
         each_scr_dict = {}
         each_scr_dict['num']  = match.group(1)
         each_scr_dict['util'] = match.group(2)
         cnsscr_dict[match.group(1)] = each_scr_dict

       match = re.search(r'active=(\S+),  enabled fkeys=(\S+), help level=(\S+),', line)
       if match:
         each_scr_dict['active']       = match.group(1)
         each_scr_dict['enabledfkeys'] = match.group(2)
         each_scr_dict['helplevel']    = match.group(3)

       match = re.search(r'nostop=(\S+),  reading=(\S+), hide=(\S+)', line)
       if match:
         each_scr_dict['nostop']       = match.group(1)
         each_scr_dict['reading'] = match.group(2)
         each_scr_dict['hide']    = match.group(3)

     cimp.terminate()

     return cnsscr_dict
         

   def __init__(self, util=None):
      """
      Parameters
       util : str    
         cns utility name. when it's omitted, the object will run command
         in cns window 6.

      """
      super(cnstool, self).__init__()
      self.util        = util       # cns utility name

      self.path        = '/usr/pde/bin/cnstool'
      self.wndw        = None       # cns window number. It needs to be str
      self.subp        = None       # cnsterm subprocess
      self.running     = False      # if cns util is running now or not
      self.quit_cmd    = 'quit'     # default util quit command
      self.timeout_sec = 5          # timeout to wait for cnstool output
      self.in_destrct  = False      # Flag to indicate we're now in destructor
      self.trim_hdr    = False      # Flag if trimming cnstool hdr
      self.pdn         = get_pdn()
      self.out_gnrtr   = ()         # output generator

      self.prompt_str  = None       # command prompt string
      self.end_msg     = None       # End message for each utility
      self.ptn_end_msg = None       
      self.ptn_cmd     = None       
      self.start_cmd   = None       

      # flags used to read cns output
      self.first_cmd     = True  
      self.found_running = False  
      self.found_reading = False  
      self.found_prompt  = False  
      self.found_util    = False  
      self.found_cmd     = False  

      # "cnscim -host" might return hostname which cannot be resolved
      if not is_valid_hostname(self.pdn):
         self.pdn    = '127.0.0.1'  

      if (self.util  == '6' 
         or not self.util):
         # Instantiate as cnstool
         self.wndw     = '6'   
      elif self.util  == '5':
         self.wndw     = '5'
      else:
         self.util     = self.util.lower()
      #   self.set_end_msg()

   def set_end_msg(self, end_msg=None):
      """
      Compile utility end message
      """
      if self.wndw == '6': 
         return

      if end_msg:
         pass
      elif self.end_msg:
         end_msg = self.end_msg
      elif self.util == 'showlocks':
         end_msg = 'ShowLocks Processing Complete'
      elif self.util == 'lokdisp':
         end_msg = 'DISPLAY UTILITY terminates'
      elif self.util == 'rebuild':
         end_msg = 'Task Exiting'
      elif self.util == 'filer':
         end_msg = 'Filer has exited'
      elif self.util == 'rcvmanager':
         end_msg = 'RCVMANAGER terminated'
      elif self.util == 'ferret':
         end_msg = 'Ferret Exited'
      elif self.util == 'qrysessn':
         end_msg = 'QrySession has terminated'
      elif self.util == 'config':
         end_msg = 'Config is about to be stopped'
      elif self.util == 'reconfig':
         end_msg = 'RECONFIG is about to be stopped'
      elif self.util == 'checktable':
         end_msg = 'CheckTable terminated'
      elif self.util == 'dbscontrol':
         end_msg = 'Exiting DBSControl'
      elif self.util == 'vprocmanager':
         end_msg = 'Exiting VprocManager'
      elif self.util == 'bardsmain':
         end_msg = '(?:already running|DSMain started|DSMain has been stopped|Error)'
      else:
         raise Exception('%s is not supported!\n' % self.util)

      self.ptn_end_msg = re.compile(end_msg)

   def _is_pde_dbs_up(self):
      pde_dbs_state = get_pdestate()
      msg  = 'PDE state: %s\n' % pde_dbs_state[0].rstrip()
      if len(pde_dbs_state) == 2:
        msg += 'DBS state: %s'   % pde_dbs_state[1].rstrip()
      self.dbglog(msg)

      if not 'RUN/' in pde_dbs_state[0]:
         self.running = False
         raise Exception('PDE is not running. Unable to run %s!\n' % self.util)

      if (len(pde_dbs_state) == 1 or
         ( not 'Logons' in pde_dbs_state[1]
         and self.util not in self.no_dbs_util) ):
         # some util can run when DBS is not fully up
         self.running = False
         raise Exception('DBS is not running. Unable to run %s!\n' % self.util)

   # start cns utility via cns window 6
   def start_util(self):
      self._is_pde_dbs_up()
      start_cmd = 'start %s' % self.util
      if self.start_cmd:
         start_cmd = self.start_cmd # Allow to override startup command e.g. filer option

      self._run_wndw6(start_cmd, True)

      invoke_cmd = ['/usr/pde/bin/cnstool','-host', self.pdn, self.wndw]
      p = self.startproc(invoke_cmd)
      self.subp = p
      self.ptn_util    = re.compile( u'%s:\u001B\u0054%s' % (self.wndw, self.util))

      self.found_running = False
      self.found_reading = False
      self.found_prompt  = False
      self.found_util    = False
      self.found_cmd     = False

      out_line = []
      # Waiting for the first prompt unless non-interactive utility
      if not self.util in self.start_only_util:
         #out_line = self._wait_prompt(cmd, out_line)
         for cmd_out in self._wait_prompt2(''):
            out_line.append(cmd_out)
 
      return out_line


   # join the existing cnstool window
   def join_wndw(self, window):
     window = str(window)

     if self.running:
       raise Exception('This %s object is already working for filer window %s!\n' % (self.util, self.wndw))

     cnswndw_dict = self.get_cnscim_s()
     if cnswndw_dict.get(window).get('util') != self.util:
       raise Exception('%s is not running in window %s!\n' % (self.util, window))

     self.wndw    = window
     self.running = 1


   # Run command in window 5
   def _run_wndw5(self, cmd=''):
      """
        Run the command in cnsterm 5 window.
        As cnsterm 5 window does not returns prompt,
        caller needs to set end message in advance

      """
      if not self.ptn_end_msg:
         raise Exception('Need to set end message for window 5!\n')

      return


   # Run command in window 6
   def _run_wndw6(self, cmd, start_util=False):
      """
        Run the command in cnsterm 6 window.
        As cnsterm 6 window returns previous output,
        this function prints timetag of current time and 
        parses the output after the tag.

      """

      wndw = '6'  # need to be str
      cnstl_cmds  = [self.path, '-host', self.pdn, wndw]
      p = self.startproc(cnstl_cmds)

      ptn_prt_bsy = self.ptn_prt_bsy

      # We parse the output after the timetag to ignore previous output
      start_timetag = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
      ptn_timetag   = re.compile( '%s' % start_timetag )
      p.stdin.write('%s:log %s\n' % (wndw, start_timetag))
      
      # cmd may contain regexp special character
      ptn_cmd     = re.compile( r'%s' % ( re.escape(cmd)) )

      hdr = ''
      if self.hdr: hdr = '%s ' % self.hdr

      found_timetag = False
      found_cmd     = False
      out_line      = []
      for line in iter(p.stdout.readline, ''):
         p.stdout.flush()
         if ptn_timetag.search(line):
            found_timetag = True
            self.dbglog('Run cmd: %s:%s' % (wndw,cmd) )
            p.stdin.write('%s:%s\n' % (wndw, cmd))
            p.stdin.flush()

         # discard previous output until current timetag found
         if not found_timetag:
            continue

         if self.m_to_stdout:  
            sys.stdout.write(hdr + line)

         self.log(line.rstrip())

         out_line.append(line)

         if ptn_prt_bsy.search(line) and start_util:
            raise Exception('Close unused cns windows!\n' )

         if ptn_cmd.search(line):
            found_cmd = True
            #self.dbglog('Found cmd' )

         if start_util:
            match = re.search(r"Started '%s' in window (\d)" % self.util,line)
            if match:
               self.wndw    = match.group(1)
               self.running = True

         if self.ptn_reading.search(line) and found_cmd:
            #self.dbglog('Found cmd and prompt in window 6' )
            if start_util and not self.wndw:
               raise Exception('Failed to start %s!\n' % self.util)
            break
      # End of for readline() loop            

      # close cnstool process each time for window 6
      p.terminate()
      return out_line
   # End of _run_wndw6()

   def _is_util_running(self):
      cnsscr_dict = self.get_cnscim_s()

      if (cnsscr_dict.get(self.wndw)
         and cnsscr_dict.get(self.wndw).get('util') == self.util):
         return True

      # utility somehow ended or not started
      self.subp.terminate()
      raise Exception('%s is not running in window %s!\n' 
               % (self.util,self.wndw)) 

   def _timeout_action(self, cmd):
      """
      Define actions in case of timeout while reading cns outpu.
      This is supposed to be called by _wait_prompt or _wait_prompt2
      """
      self._is_pde_dbs_up()

      msg  = 'cnstool not return output for %d sec\n' % self.timeout_sec
      msg += 'Checking if %s is running using cnscim' % self.util
      self.dbglog(msg)

      self._is_util_running()

      if (not self.util in self.start_only_util
          and
          (self.first_cmd or self.found_running == False)):
         if self.first_cmd:    
            self.dbglog('Re-running the first command')
         if not self.found_running: 
            self.dbglog('cns window did not return "Running" message')

         self.first_cmd = False
         self.subp.stdin.write('%s:%s\n' % (self.wndw, cmd) )
         self.subp.stdin.flush()

      self.dbglog('%s is in cnscim window %s. Continue to monitor.'
                  % (self.util, self.wndw))
      return

   def _can_stop_reading(self, line):
      """
      This is called by _wait_prompt. This checks if we can stop reading the output from cnstool.

      """

      if self.ptn_running.search(line):
         self.found_running = True
      elif self.ptn_cmd and self.ptn_cmd.search(line):
        # self.ptn_cmd(inc window#) is not set as of util invocation 
         self.found_cmd = True
         self.dbglog('Found cmd: "%s" ' % line.rstrip() )

      elif self.ptn_util.search(line):
         self.dbglog('Found util name in window %s ' % self.wndw )
         self.found_util = True

      elif self.prompt_str and self.ptn_prompt.search(line):
         self.found_prompt = True
         self.dbglog('Found prompt string')

      elif self.ptn_reading.search(line):
         self.found_reading = True
         self.dbglog('Found "Reading" message')


      if self.found_util and self.found_reading:
         # We're reading till first prompt right after starting utility from window 6.
         # We're yet to submit the first command. we return to submit it.
         self.dbglog('Found utility name and "Reading". Stop reading window %s' % self.wndw )
         return True

      if self.found_cmd and self.found_reading:
         if not self.prompt_str:
            self.dbglog('Found the command and "Reading". Stop reading window %s' % self.wndw )
            return True
         elif self.found_prompt:
            self.dbglog('Found the command and "Reading" and the prompt. Stop reading window %s' % self.wndw )
            return True

      # Stop reading if find end message after command or utility name
      if (self.found_cmd or self.found_util) and self.ptn_end_msg.search(line):
         self.dbglog('End message found in window %s' % self.wndw)
         self.running = False
         return True

      return False

   # This method used when reading till the first prompt after starting util
   def _wait_prompt(self, cmd, out_line):
      """
      Read cnstool output till prompt is returned.
      We expect 'Reading' as prompt because some utilities such as 
      lokdisp return various prompt messages.
 
      When cnstool does not return output after (self.timeout_sec) sec
      we run cnscim and see if the utility is still running because
      cnstool may not return prompt correctly or we may fail to parse it.

      We exit if the utility is not running for any reason.
      Otherwise, we do NOT exit because it may be expected to take long 
      time to return output(e.g. starting filer, checktable is blocked by lock)

      """
      p = self.subp


      hdr = ''
      if self.hdr: hdr = '[%s] ' % self.hdr

      while True:
         try:
            if self.in_destrct:   
               # Not set timeout in destructor
               line = p.stdout.readline()
            else:
               # cnstool may not return prompt/end message correctly.
               with Timeout(self.timeout_sec):
                  line = p.stdout.readline()

         except Timeout.Timeout:
            self._timeout_action(cmd)
         # End of except Timeout.Timeout
         # We do NOT exit as long as the utility is running.

         if self.m_to_stdout:  
            sys.stdout.write(hdr + line)

         self.log(line.rstrip())

         out_line.append(line)

         if self._can_stop_reading(line):
            break

         p.stdout.flush()
      # End of while loop

      return out_line
   # End of _wait_prompt()


   def _wait_prompt2(self, cmd):
      """
      generator version of _wait_prompt(). This method is supposed to be used
      when running command which takes time e.g. check all tables

      """
      p = self.subp

      hdr = ''
      if self.hdr: hdr = '[%s] ' % self.hdr

      while True:
         try:
            if self.in_destrct:   
               # Not set timeout in destructor
               line = p.stdout.readline()
            else:
               # cnstool may not return prompt/end message correctly.
               with Timeout(self.timeout_sec):
                  line = p.stdout.readline()

         except Timeout.Timeout:
            self._timeout_action(cmd)
         # End of except Timeout.Timeout
         # We do NOT exit as long as the utility is running.

         if self.m_to_stdout:  
            sys.stdout.write(hdr + line)

         self.log(line.rstrip())

         yield line

         if self._can_stop_reading(line):
            break

         p.stdout.flush()
      # End of while loop

      return 
   # End of _wait_prompt2()

      
   def run_cmd(self, cmd):
      """
      Run command list

      Input:  cmd (str or list[str]) - command string. 
      Return: list - output from cns utility

      """
      out_line = []
      if isinstance(cmd, str):
         cmd = [cmd]

      if not isinstance(cmd, list):
         return False

      for each_cmd in cmd:
         self.run_each_cmd(each_cmd, True)
         for cmd_out in self.out_gnrtr:
            out_line.append(cmd_out)

      return out_line

   def run_cmd2(self, cmd):
     """
     generator version of run_cmd()

     Input:  cmd (str or list[str]) - command string. 
     Return: generator - generates output from cns utility

     caller needs to iterate till StopIteration

     """
     if isinstance(cmd, str):
       cmd = [cmd]

     if not isinstance(cmd, list):
       raise Exception('run_cmd2() - argument must be str or list of str!\n')

     for each_cmd in cmd:
       self.run_each_cmd(each_cmd, True)
       for cmd_out in self.out_gnrtr:
         yield cmd_out
   
     return 

   def run_each_cmd(self, cmd, generator=False):
      tmp_cmd = cmd.rstrip()
      if self.ptn_crlf.search(tmp_cmd):
         raise Exception('LF/CRLF in middle of command is not expected: "%s" !!\n' % tmp_cmd)

      if self.wndw == '6': 
         # we just run command in window 6
         return self._run_wndw6(cmd)

      # Need to set prompt_str and ptn_end_msg here as start_util() calls
      # wait_prompt()
      if self.prompt_str is not None:
         # Some utilities return 'Reading' prompt right after submitting command 
         # e.g. checktable, ferret
         self.ptn_prompt  = re.compile( self.prompt_str )

      if not self.ptn_end_msg:
         self.set_end_msg()

      if not self.wndw and self.util:
         # cns utility not invoked yet. let's invoke it now
         self.start_util()

      if not self.running:
         # utility failed to start or already exited
         raise Exception('%s not running in window %s!\n' 
                          % (self.util,self.wndw))

      out_line    = []

      # Some utilities require semicolon after each command
      cmd = cmd.rstrip()
      if self.util in self.semicolon_util:
         if not re.search(';\s*$',cmd):
            cmd += ';'

      # read the cns window output till the last prompt in case the caller did not 
      for prev_cmd_out in self.out_gnrtr:
         pass

      p = self.subp

      # Not submit command for non-interactive utility(e.g. showlocks)
      # as it would be parsed by subsequent utility in the same window
      if not self.util in self.start_only_util:
         p.stdin.write('%s:%s\n' % (self.wndw, cmd) )
         p.stdin.flush()
         
      # set variables used in _wait_prompt and _wait_prompt2
      self.found_running = False
      self.found_reading = False
      self.found_prompt  = False
      self.found_util    = False
      self.found_cmd     = False

      # escaping cmd as it may contain regexp special character
      self.ptn_cmd     = re.compile( r'^%s:%s\s*$' % (self.wndw, re.escape(cmd)) )

      if self.util in self.start_only_util:
         self.found_cmd = True

      if generator:
         self.out_gnrtr = self._wait_prompt2(cmd)
         return 

      # generator should be always true. we should not be here

      out_line = self._wait_prompt(cmd, out_line)
      return out_line
   # End of run_each_cmd()


   # Return cns window number as str
   def get_wndw(self):
      return self.wndw

   # Set prompt for cnstool. Default is ':Reading'
   # You can override it when cns utility returns prompt too fast.
   # e.g. checktable/ferret immediately return ':Reading'.
   def set_prompt(self, prompt_str=None):
      self.prompt_str = prompt_str

   # Set flag if trimming cnstool output header
   def set_trim_hdr(self, trim_hdr=False):
      self.trim_hdr = trim_hdr

   # Set read timeout second for cnstool output
   def set_timeout(self, timeout_sec=5):
      self.timeout_sec = timeout_sec

   # return if cns util is running now or not
   def is_running(self):
      return self.running

   def quit(self):
      if (self.wndw == '6' or self.wndw == '5'):
         return
      if not self.running:
         return

      self.log('%s exited in window %s.' % (self.util, self.wndw) )
      
      out_line = []
      for cmd_out in self.run_cmd(self.quit_cmd):
        out_line.append(cmd_out)
        
      return out_line

   def __del__(self):
      self.in_destrct = True 
      if (self.auto_quit 
          and self.subp
          and self.subp.poll is not None):
         self.quit()
         self.subp.terminate()
      return
## End of cnstool class
  

class cnswndw5(cnstool):

   def __init__(self):
      super(cnswndw5, self).__init__('5')
      self.timeout_sec = 1         # timeout to wait for cnstool output
      self.ptn_end_msg = []

      wndw = '5'  # need to be str
      cnstl_cmds = [self.path, '-host', self.pdn, wndw]
      self.subp  = self.startproc(cnstl_cmds)

   def run_cmd(self, cmd):
      if not self.subp:
         raise Exception('Not connected to window 5 yet!\n')

      p = self.subp
      p.stdin.write(cmd.rstrip() + '\n')
      p.stdin.flush()
         

   def set_start_msg(self, msg):
      """
      Set start message(s).
      """
      if isinstance(msg, str):
         msgs = [msg]
      elif isinstance(msg, list):
         msgs = msg
      
      self.ptn_start_msg = []
      for msg in msgs:
         ptn  = re.compile(msg)
         self.ptn_start_msg.append(ptn)

   def set_end_msg(self, msg):
      """
      Set end message(s).
      """
      if isinstance(msg, str):
         msgs = [msg]
      elif isinstance(msg, list):
         msgs = msg
      
      self.ptn_end_msg = []
      for msg in msgs:
         ptn  = re.compile(msg)
         self.ptn_end_msg.append(ptn)


   def read_wndw(self):
      """
      Read cns window 5 until timeout or the end message is found.

      """
      if not self.subp:
         raise Exception('Not connected to window 5 yet!\n')

      p               = self.subp
      found_start_ptn = []
      found_end_ptn   = []
      out_line      = []
      while True:
         try:
            # cnstool may not return prompt/end message correctly.
            with Timeout(self.timeout_sec):
               line = p.stdout.readline()

         except Timeout.Timeout:
            self.dbglog('cns window 5 did not return output %d sec.' % self.timeout_sec)
            break

         if self.trim_hdr:
            line = self.ptn_cnshdr.sub('', line)

         if self.m_to_stdout:
            sys.stdout.write(line)

         out_line.append(line)

         for ptn1 in self.ptn_end_msg:
            if ptn1.search(line):
               found_end_ptn.append(ptn1)
               break

         if (self.ptn_end_msg and 
            sorted(found_end_ptn) == sorted(self.ptn_end_msg)):
            # break if all messages are matched.
            break

      return out_line
