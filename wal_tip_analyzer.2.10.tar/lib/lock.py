#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  X.XX (being developed)

 Description:
  This module provides API so you can easily operate 
  lock related operation(e.g. lokdisp) via python script.

"""
version='1.00'

import sys, os
from os import path
import re
from cnsutil import cnstool  # super class

class lokdisp(cnstool):

  ptn_ampno = re.compile(r'AMP (\d+) REPORTS \d+ LOCK ENTRIES')
  ptn_txnno = re.compile(r'Tran.* (\d+ [0-9A-F]{8})')

  def __init__(self):
    super(lokdisp, self).__init__('lokdisp')
    self.end_msg   = 'LOCK DISPLAY UTILITY terminates'

  def get_blockers(self, file=None):
    
    if file:
      lines = open(file, 'r')
    else:
      lines = self.run_cmd(['blocker','all'])
      
    blksts   = BlockStatus()
    cur_blkd_txnno = '' 
    cur_blkr       = '' 

    ptn_lck_mode    = re.compile(r'lock mode\s+: (\S+)')
    ptn_lck_sts     = re.compile(r'lock status\s+: (\S+)')
    ptn_lck_objtype = re.compile(r'lock objectType\s+: (\S+)')
    ptn_dbid        = re.compile(r'DBID      : ([0-9A-F]{8})')
    ptn_dbname      = re.compile(r'DBNAME    : (.*)')
    ptn_tid         = re.compile(r'TableID   : (.*),')
    ptn_tblname     = re.compile(r'TableName : (.*)')
    ptn_rowhash1    = re.compile(r'RowHash1  : ([0-9A-F]{8})')
    ptn_rowhash2    = re.compile(r'RowHash2  : ([0-9A-F]{8})')

    for line in lines:
      match = self.ptn_ampno.search(line)
      if match:
        blksts.blkamps.append(match.group(1))

      match = self.ptn_txnno.search(line)
      if match:
        if 'Blocked' in line:
          cur_blkd_txnno = match.group(1)
        if 'Blocker' in line:
          cur_blkr       = Lock()
          cur_blkr.txnno = match.group(1)

      match = ptn_lck_mode.search(line)
      if match:
        cur_blkr.mode = match.group(1)

      match = ptn_lck_sts.search(line)
      if match:
        cur_blkr.granted = match.group(1)

      match = ptn_lck_objtype.search(line)
      if match:
        cur_blkr.objtype = match.group(1)

      match = ptn_dbid.search(line)
      if match:
        cur_blkr.dbid = match.group(1)

      match = ptn_dbname.search(line)
      if match:
        cur_blkr.dbname = match.group(1)

      match = ptn_tid.search(line)
      if match:
        cur_blkr.tid = match.group(1)

      match = ptn_tblname.search(line)
      if match:
        cur_blkr.tblname = match.group(1)

      match = ptn_rowhash1.search(line)
      if match:
        cur_blkr.rowhash1 = match.group(1)

      match = ptn_rowhash2.search(line)
      if match:
        cur_blkr.rowhash2 = match.group(1)
        blksts.roottxn[cur_blkr.txnno] = cur_blkr  # Need fix! root blocker may have multiple blocker locks


    if file:
      f.close()

    return blksts

  def get_blocking(self):
    blkamps = []
    for line in self.run_cmd(['blocker','all']):
      match = self.ptn_ampno.search(line)
      if match:
        blkamps.append(match.group(1))

    if not blkamps:
      return False  # No blocking

    for amp in sorted(blkamps):
      self.run_cmd(['Tran', '%s' % amp])


class showlocks(cnstool):

   ptn_tbl = re.compile(r'([^":]+\.[\S]+)\s*$')
   ptn_lck = re.compile(r'USER (\S+)\s+MODE (\S+)\s*AMP (\d+|All Amps)\s+(JobId: (\d+))?')

   def __init__(self):
      super(showlocks, self).__init__('showlocks')
      self.end_msg    = 'ShowLocks Processing Complete'
      self.start_only = True
      self.lock_dict  = {}    # Key: object name  Value: HUTLock instance

   def start(self):
      out_line = self.run_cmd('')
      self.set_lock_info(out_line)   
      return out_line
   
   def set_lock_info(self, input):
      lock      = None
      prev_line = None

      open_file = False
      if isinstance(input, file):
         self.input = iter(input.readline, '')
      elif isinstance(input, list):
         self.input = input
      elif path.isfile(input):
         self.input = open(input, 'r')
         open_file  = True


      for line in self.input:

         if self.ptn_prompt.search(line): # This regex pattern is from super class
            continue
         if re.search(r'^(?:\d:)?\s*$' , line):
            continue
         if re.search(r'^(?:\d:)?Running\s*$' , line):
            continue

         match = self.ptn_lck.search(line)
         if match:
            lock = HUTLock()
            lock.user  = match.group(1)
            lock.mode  = match.group(2)
            lock.ampno = match.group(3)
            lock.jobid = match.group(5)
           
            # Now, previous line has object info

            if prev_line.lstrip()[1] == ':' :
               prev_line = prev_line.lstrip()[2:] # remove cnstool header

            objname      = prev_line.strip()
            lock.objname = objname

            if '.' in prev_line:
               lock.dbname, lock.tblname = objname.split('.')
            else:
               lock.dbname = objname

            self.lock_dict[objname] = lock

         prev_line = line
      
      if open_file:
         self.input.close()

   def get_objname(self):
      return self.lock_dict.keys()

   def get_hutlock(self, objname=None):
      """
      Return HUTLock object based on object name
      """
      if objname is not None:
         return self.lock_dict.get(objname)
      return self.lock_dict.values()

   def get_release_lock(self, override=False):
      """
      Return: RELEASE LOCK statement based on lock_dict as list
      """
      out_line = []
      if not self.lock_dict:
         return out_line  

      for objname in sorted(self.lock_dict.keys()):
         hutlock = self.get_hutlock(objname)
         
         objname  = '"%s"' % hutlock.dbname
         if hutlock.tblname:
            objname += '."%s"' % hutlock.tblname
         rel_sql  = 'RELEASE LOCK %s' % objname
         if hutlock.jobid:
            rel_sql  += ' WHERE jobid=%s' % hutlock.jobid
         if override:
            rel_sql  += ', override'

         rel_sql += ';'
         rel_sql  = r'%-40s /* %s lock is held by user %s */' % (rel_sql, hutlock.mode, hutlock.user)

         out_line.append(rel_sql)

      return out_line

class BlockStatus(object):
  def __init__(self):
    self.blkamps   = [] 
    self.roottxn   = {}

class Lock(object):
  def __init__(self):
    self.dbname   = None
    self.tblname  = None    # None if DB level lock
    self.objname  = None    
    self.objtype  = None    
    self.dbid     = None    
    self.tid      = None    
    self.rowhash1 = None    
    self.rowhash2 = None    
    self.mode     = None
    self.range    = None
    self.ampno    = None
    self.user     = None   
    self.txnno    = None   
    self.sesno    = None   
    self.reqno    = None   
    self.granted  = None   

class HUTLock(Lock):
   def __init__(self):
      super(HUTLock, self).__init__()
      self.jobid    = None    # DSA16.0 and later only
      return

def main():

   return

if __name__ == "__main__":
   main()
