#!/usr/bin/python

import pty, os, sys, re
import threading
from optparse import OptionParser, SUPPRESS_HELP

import select
from time import sleep, time
from os import fork, waitpid, execv, read, write, WNOHANG

class secureclient(object):

    def __init__(self, host=None, user=None, askpass=True, pw=None, timeout=0, debug=False):
        self.host    = host
        self.user    = user
        self.askpass = askpass
        self.timeout = timeout
        self.debug   = debug

        self.pw      = pw
        if isinstance(pw, str):
           self.pw   = pw.encode('utf-8') # For Python3 

    def dbglog(self, msg):
        if not self.debug: 
           return
        print('DEBUG: ' + msg)

    def wait(self, timeout=0):
        if not self.is_running:
           return False, False

        pid      = self.ssh_pid
        child_fd = self.child_fd

        ## if we havn't setup pub-key authentication
        ## we can loop for a password promt and "insert" the password.
        output = ''
        start  = time()
        ret    = None
        while self.askpass:
           now = time()
           if self.timeout and (now - start) > self.timeout:
              self.is_running = False
              return output.split('\n'), ret

           r, w, e = select.select([ child_fd ], [], [], 1)
           if child_fd not in r:
              self.dbglog('%s %s output from ssh not ready to read: 1' % (self.host, self.cmd))
              continue

           try:
              tmpout = read(child_fd, 1024)
              lower  = tmpout.lower()
              if isinstance(tmpout, bytes):
                 # Python3 differentiates bytes from string
                 tmpout = tmpout.decode()
              output += tmpout
           except:  
              # OSError 'Input/output error' is raised when read() fails
              break

           # Write the password. write() requires bytes object as input in Python3
           if b'password:' in lower:
              write(child_fd, self.pw + b'\n')
              break
           elif b'are you sure you want to continue connecting' in lower:
              # Adding key to known_hosts
              write(child_fd, b'yes\n')
              sleep(1)
           elif b'company privacy warning' in lower:
              pass # This is an understood message

        self.dbglog('Got out first loop %s' % output)

        # This 2nd while loop reads ssh stdout when we need to enter password
        start = time()
        while True:
          now = time()
          if self.timeout and (now - start) > self.timeout:
             self.is_running = False
             return output.split('\n'), ret

          r, w, e = select.select([ child_fd ], [], [], 1)
          if child_fd not in r:
             self.dbglog('%s %s output from ssh not ready to read: 2' % (self.host, self.cmd))
             continue

          try:
            tmpout = read(child_fd, 1024) 
            if isinstance(tmpout, bytes):
               # Python3 differentiates bytes from string
               tmpout = tmpout.decode()
            output += tmpout
          except:
            break

        start = time()
        self.dbglog('Waiting pid %d' % pid)
        while True:
          cpid, ret = waitpid(pid, os.WNOHANG)
          if cpid == pid:
             break
          sleep(1)

          # We should not hung here. But set timeout just in case
          now = time()
          self.dbglog('%s timeout setting %s' % (self.host, self.timeout))
          if self.timeout and (now - start) > self.timeout:
             self.dbglog('%s Timeout!' % self.host)
             break
  
        self.is_running = False
        return output.split('\n'), ret
# End of secureclient class

class ssh(secureclient):

   def __init__(self, host, askpass=True, user=None, pw=None, timeout=0, debug=False):
      super(ssh, self).__init__(host=host, askpass=askpass, user=user, pw=pw, timeout=timeout, debug=debug)
      self.ssh_pid    = None
      self.child_fd   = None
      self.is_running = False
      self.cmd        = None
      
   def run(self, cmd, wait=True):
      # Return - tuple (ssh stdout: list[str], return code of ssh: int)

      if self.is_running:
         return False

      command = [
         '/usr/bin/ssh',
         self.user+'@'+self.host,
         '-o', 'NumberOfPasswordPrompts=1', # We don't retry if password does not work
         cmd ,
      ]
      self.cmd = cmd

      pid, child_fd = pty.fork()

      if not pid: # Child process
         execv(command[0], command) # first argumet will be args[0] (program name of exec process)

      self.ssh_pid    = pid
      self.child_fd   = child_fd
      self.is_running = True

      if not wait:
         return

      output, ret = self.wait()
      return output, ret


class scp(secureclient):

   def __init__(self, host, user, pw, askpass=True, host2=None, user2=None, askpass2=True, pw2=None, timeout=0, debug=False):
      super(scp, self).__init__(host, askpass=askpass, user=user, pw=pw, timeout=timeout, debug=debug)
      self.cmd = None
      self.host    = host
      self.user    = user
      self.askpass = askpass
      self.pw      = pw

      # scp allows to specify 2 remote hosts at a time (this module does not support it yet)
      self.host2    = host2
      self.user2    = user2
      self.askpass2 = askpass2
      self.pw2      = pw2

   def send(self, src, tgt):
      # Return - tuple (scp stdout: list[str], return code of scp: int)

      self.cmd = [
         '/usr/bin/scp',
         '-rp',
         '-o', 'NumberOfPasswordPrompts=1', # We don't retry if password does not work
         src,
         self.user+'@'+self.host+':'+tgt
      ]
      return self._start()

   def receive(self, src, tgt):
      # Return - tuple (scp stdout: list[str], return code of scp: int)

      self.cmd = [
         '/usr/bin/scp',
         '-rp',
         '-o', 'NumberOfPasswordPrompts=1', # We don't retry if password does not work
         self.user+'@'+self.host+':'+src,
         tgt,
      ]
      return self._start()

   def _start(self):
      pid, child_fd = pty.fork()

      if not pid: # Child process
         execv(self.cmd[0], self.cmd) # first argumet will be args[0] (program name of exec process)

      self.ssh_pid    = pid
      self.child_fd   = child_fd
      self.is_running = True

      output, ret = self.wait()
      return output, ret


def main():

  pyver = '.'.join(map(str, sys.version_info[0:3]))
  print('Running Python version: %s' % pyver)
 
  hostnum       = 1999
  end_hostnum   = 2099
  hosts         = []
  skiphost      = []
  

  while hostnum < end_hostnum:
    hostnum  += 2
    hostname = 'lnx' + str(hostnum)
    if hostname in skiphost:
      continue
    hosts.append(hostname)

  threads = []
  thread_return = {}

  #hosts = ['10.20.100.1']
  print('Checking SW ver from lnx2001 to lnx2099')
  for host in hosts:
     print('### ' + host)
     s = ssh(host, user='root', pw='dbsteam4me', timeout=5, debug=True)
     output, ret = s.run('rpm -qa | egrep "tptbase|fastexp"')
     for line in output:
       print line.rstrip()


# End of main()

if __name__ == '__main__':
  main()

