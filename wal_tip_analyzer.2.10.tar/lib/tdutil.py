#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:
  This is library for frequently-used operation
  regarding Teradata DBS support.

"""
version='1.00'

import sys, os
import re
from extutil import ExternalUtil 

def get_pdn():
   cmds = ['/usr/pde/bin/cnscim', '-hostname']
   p    = ExternalUtil.startproc(cmds)
   pdn  = (p.stdout.read()).rstrip()
   p.terminate()
   return pdn

# Return 'pdestate -a' as list
# list[0]: PDE state, list[1]: DBS state
def get_pdestate():
   cmds     = ['/usr/pde/bin/pdestate', '-a']
   p        = ExternalUtil.startproc(cmds)
   pdestate = p.stdout.readlines()
   p.terminate()
   return pdestate


ptn_hex_str  = re.compile(r'^[0-9A-F]+$') 
def flip_byte(hex_chr):
   match = ptn_hex_2chr.search(hex_chr.strip())
   if not match:
      return False
   return '%s%s' % (match.group(2), match.group(1))


def main():
   pdestate, dbsstate = get_pdestate()
   print(pdestate)
   print(dbsstate)


if __name__ == '__main__':
   main()
