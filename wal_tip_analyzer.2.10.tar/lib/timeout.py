#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  1.00 Initial release

 Description:


"""
version='1.00'

import signal
import sys, time
import subprocess


class Timeout(object):
    """
    Timeout class using ALARM signal.
    This is supposed to be used with "with" statement 
    to make sure to enable/disable SIGALRM
    """
    class Timeout(Exception):
        pass
 
    def __init__(self, sec):
        self.sec = sec
 
    def __enter__(self):
        signal.signal(signal.SIGALRM, self.raise_timeout)
        signal.alarm(self.sec)
 
    def __exit__(self, *args):
        signal.alarm(0)    # disable alarm
 
    def raise_timeout(self, *args):
        raise Timeout.Timeout()


def main():

   cmds = ['cnstool', '6']
   p = subprocess.Popen(cmds,
               stdin=subprocess.PIPE,
               stdout=subprocess.PIPE,
               stderr=subprocess.STDOUT
               ,universal_newlines=True  # open in text mode
               ,bufsize=1                # buffer line by line
   )

   timeout = 5
   while True:
      #line = run_with_timeout(timeout, None, p.stdout.readline)
      try:
         with Timeout(5):
            line = p.stdout.readline()

      except Timeout.Timeout as e:
         print('Timeout! %s' % e)
         break

      sys.stdout.write(line)

   print('Got out of loop!')
   return


if __name__ == "__main__":
   main()
