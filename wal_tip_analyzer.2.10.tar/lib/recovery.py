#! /usr/bin/python
"""
 History:
  06Jan2020 ym186001  X.XX (being developed)

 Description:
  This module provides API so you can easily operate 
  rebuild utility via python script.

"""
version='1.00'

import sys, os
import re
from cnsutil import cnstool  # super class


class rcvmanager(cnstool):

   def __init__(self):
      super(rcvmanager, self).__init__('rcvmanager')
      self.end_msg    = 'RCVMANAGER terminated'
      self.semicolon  = True

