#! /usr/bin/python
"""
 History:
  XXJan2020 ym186001  1.00 (being developed)

 Description:
  Provide API so Python script can handle dbscontrol

"""
version='1.00'

import sys, os, time
import re

from extutil import ExternalUtil  # super class


class dbscontrol(ExternalUtil):
   """
   API so python script operates dbscontrol.

   """
   def __init__(self):
      """
      Parameters

      """
      super(dbscontrol, self).__init__()
      self.path        = '/usr/tdbms/bin/dbscontrol'
      self.numlf       = 2     # Number of LF to return prompt
      self.vproc_dict  = {}    # Key: vproc#(str) Value: Vproc object

      self.to_stdout(False)

      self.subp = self.startproc(self.path, 0)
      #self.subp.stdout.flush()


   def set_numlf(self, numlf=2):
      self.numlf = numlf


   def run_cmd(self, cmd):
      """
      Run dbscontrol command and read the output till next prompt.

      """
      p   = self.subp
      cmd  = cmd.rstrip()
      cmd += '\n' 
      p.stdin.write(cmd) 
   
      out_line   = []
      prpt_found = 0
      startup    = False
      for line in iter(p.stdout.readline, ''):
         sys.stdout.flush()
         self.m_to_stdout and sys.stdout.write(line)
         out_line.append(line)

         if 'DBSControl Utility' in line:
            # This is first command. Need to read prompt twice
            startup = True 

         if 'Enter a command' in line:
            if not startup:
               break
            prpt_found += 1
            if prpt_found >= 2:
               break

      return out_line
      

   #def quit(self):
   #   if self.subp.poll is not None:
   #      self.subp.stdin('quit\n')


def main():
   dc = dbscontrol()
   dc.to_stdout()
   dc.run_cmd('di ')


if __name__ == '__main__':
   main()
